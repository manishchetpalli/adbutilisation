"""
SparkJobOptimizerAnalyzer — Class 2 (Plugin 1).

Consumes a ``ScanResult`` from ``SparkJobOptimizerScanner`` and produces:
  - A colour-coded multi-sheet Excel workbook (.xlsx)
  - Per-category CSV files in a ``csv/`` sub-directory
  - (Optional) Two Delta tables in Unity Catalog when ``write_to_delta`` is "Y"

Excel workbook sheet layout
----------------------------
| Sheet                | Content                                   |
|----------------------|-------------------------------------------|
| Summary              | Scan metadata + issue counts per category |
| Skewed_Jobs          | Data skew findings with skew ratio        |
| Shuffle_Spill        | Queries with high disk spill (MB)         |
| Small_Files          | Delta tables with excessive small files   |
| Broadcast_Candidates | Joins eligible for broadcast hint         |
| Long_Running_Jobs    | Jobs exceeding P95 duration               |
| Failed_Tasks         | Jobs with high task failure rate          |
| Delta_Issues         : Tables needing OPTIMIZE / VACUUM          |
| Recommendations      | All actionable fixes (priority + SQL)     |

Colour coding (Recommendations sheet)
--------------------------------------
  RED    (#FFCCCC) — HIGH priority
  AMBER  (#FFEDCC) — MEDIUM priority
  GREEN  (#CCFFCC) — LOW priority

Delta output (when ``write_to_delta`` = "Y")
--------------------------------------------
  {catalog}.{schema}.spark_job_optimizer_findings        — one row per finding
  {catalog}.{schema}.spark_job_optimizer_recommendations — one row per recommendation

Set in config:
  spark_job_optimizer.output.write_to_delta  : "Y" or "N"  (default "N")
  spark_job_optimizer.output.delta_catalog   : catalog name (default "dbscannercatalog")
  spark_job_optimizer.output.delta_schema    : schema  name (default "catalog_inventory")
"""

import json
import logging
import os
import uuid
from datetime import datetime
from typing import List, Optional

import pandas as pd

from ..models.spark_optimizer_models import OptimizationRecommendation, ScanResult
from .spark_recommendation_engine import SparkRecommendationEngine

logger = logging.getLogger(__name__)

# openpyxl colour constants (no leading #)
_COL_HIGH    = "FFCCCC"   # soft red
_COL_MEDIUM  = "FFEDCC"   # soft amber
_COL_LOW     = "CCFFCC"   # soft green
_COL_HEADER  = "2F5597"   # deep blue
_FONT_HEADER = "FFFFFF"   # white text


class SparkJobOptimizerAnalyzer:
    """
    Post-scan report generator for Spark Job Optimizer findings.

    Parameters
    ----------
    config : Plugin configuration dict / object.  The analyzer reads the
             ``spark_job_optimizer.output`` sub-key for default output
             directory settings.
    """

    # Maps ScanResult attribute name → Excel sheet name
    _SHEET_MAP: dict = {
        "skewed_jobs"         : "Skewed_Jobs",
        "shuffle_spill_jobs"  : "Shuffle_Spill",
        "small_file_jobs"     : "Small_Files",
        "broadcast_candidates": "Broadcast_Candidates",
        "long_running_jobs"   : "Long_Running_Jobs",
        "failed_tasks"        : "Failed_Tasks",
        "delta_issues"        : "Delta_Issues",
    }

    def __init__(self, config):
        if isinstance(config, dict):
            plugin_cfg = config.get("spark_job_optimizer", {})
        else:
            plugin_cfg = getattr(config, "spark_job_optimizer", {}) or {}

        output_cfg = plugin_cfg.get("output", {}) if isinstance(plugin_cfg, dict) else {}

        self._config        = config
        self._output_dir    = output_cfg.get("output_dir", "./output/spark_optimizer")
        self._write_to_delta: bool = str(output_cfg.get("write_to_delta", "N")).upper() == "Y"
        self._delta_catalog : str  = output_cfg.get("delta_catalog", "dbscannercatalog")
        self._delta_schema  : str  = output_cfg.get("delta_schema",  "catalog_inventory")
        self._rec_engine    = SparkRecommendationEngine(
            config if isinstance(config, dict) else {}
        )

    # ──────────────────────────────────────────────────────────────
    # Class 2 — Public API
    # ──────────────────────────────────────────────────────────────

    def generate_report(
        self,
        scan_result : ScanResult,
        output_path : str,
    ) -> str:
        """
        Master method — generates the full Excel workbook, CSV files, and
        optionally writes findings + recommendations to Unity Catalog Delta tables.

        Parameters
        ----------
        scan_result : Populated ``ScanResult`` from ``SparkJobOptimizerScanner``.
        output_path : Absolute path (including .xlsx filename) for the workbook.

        Returns
        -------
        str — path to the generated Excel file.
        """
        # Stable scan_id derived from workspace + timestamp for cross-table joins
        scan_id = f"{scan_result.workspace_id}_{scan_result.scan_timestamp.strftime('%Y%m%d_%H%M%S')}"

        # Ensure output directory exists
        output_dir = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(output_dir, exist_ok=True)

        logger.info("[SparkJobOptimizer] Generating report → %s", output_path)

        recommendations = self._rec_engine.generate_recommendations(scan_result)

        with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
            self._write_summary_sheet(writer, scan_result)

            for attr, sheet_name in self._SHEET_MAP.items():
                df = getattr(scan_result, attr, pd.DataFrame())
                self._write_findings_sheet(writer, sheet_name, df)

            self._write_recommendations_sheet(writer, recommendations)
            self._apply_formatting(writer.book)

        # Export per-category CSVs alongside the workbook
        csv_dir = os.path.join(output_dir, "csv")
        self._export_csv(scan_result, csv_dir)

        # Optional Delta table write (controlled by write_to_delta: Y|N)
        if self._write_to_delta:
            self._write_to_delta_tables(scan_result, recommendations, scan_id)

        logger.info(
            "[SparkJobOptimizer] Report complete — findings: %d | recommendations: %d",
            scan_result.total_findings,
            len(recommendations),
        )
        return output_path

    # ──────────────────────────────────────────────────────────────
    # Sheet writers
    # ──────────────────────────────────────────────────────────────

    def _write_summary_sheet(self, writer, scan_result: ScanResult) -> None:
        """
        Executive summary sheet — workspace metadata followed by per-category
        finding counts and a grand total.
        """
        meta_rows = [
            ("Workspace ID",    scan_result.workspace_id),
            ("Workspace Name",  scan_result.workspace_name),
            ("Scan Timestamp",  str(scan_result.scan_timestamp)),
            ("Scan Mode",       scan_result.scan_mode),
            ("Lookback Days",   scan_result.lookback_days),
        ]
        meta_df = pd.DataFrame(meta_rows, columns=["Property", "Value"])

        findings_rows = [
            ("Data Skew",            len(scan_result.skewed_jobs)),
            ("Shuffle Spill",        len(scan_result.shuffle_spill_jobs)),
            ("Small Files",          len(scan_result.small_file_jobs)),
            ("Broadcast Candidates", len(scan_result.broadcast_candidates)),
            ("Long Running Jobs",    len(scan_result.long_running_jobs)),
            ("Failed Tasks",         len(scan_result.failed_tasks)),
            ("Delta Issues",         len(scan_result.delta_issues)),
            ("TOTAL",                scan_result.total_findings),
        ]
        findings_df = pd.DataFrame(findings_rows, columns=["Category", "Findings"])

        # Write metadata block starting at row 0, findings table below it
        meta_df.to_excel(writer, sheet_name="Summary", index=False, startrow=0)
        findings_df.to_excel(
            writer,
            sheet_name="Summary",
            index=False,
            startrow=len(meta_df) + 2,
        )

    def _write_findings_sheet(
        self, writer, sheet_name: str, df: pd.DataFrame
    ) -> None:
        """
        Writes a single finding DataFrame to the named Excel sheet.
        Writes a placeholder row when the DataFrame is empty.
        """
        if df.empty:
            placeholder = pd.DataFrame([{"message": "No findings in this category"}])
            placeholder.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    def _write_recommendations_sheet(
        self, writer, recommendations: List[OptimizationRecommendation]
    ) -> None:
        """Serialises all OptimizationRecommendation objects to the final sheet."""
        if not recommendations:
            pd.DataFrame([{"message": "No recommendations generated"}]).to_excel(
                writer, sheet_name="Recommendations", index=False
            )
            return

        rows = []
        for rec in recommendations:
            rows.append({
                "recommendation_id": rec.recommendation_id,
                "finding_id"       : rec.finding_id,
                "category"         : rec.category,
                "priority"         : rec.priority,
                "issue_summary"    : rec.issue_summary,
                "actions"          : "\n".join(rec.actions),
                "sql_scripts"      : "\n\n".join(rec.sql_scripts),
                "estimated_savings": rec.estimated_savings,
                "reference_docs"   : "\n".join(rec.reference_docs),
            })
        pd.DataFrame(rows).to_excel(writer, sheet_name="Recommendations", index=False)

    # ──────────────────────────────────────────────────────────────
    # Formatting
    # ──────────────────────────────────────────────────────────────

    def _apply_formatting(self, workbook) -> None:
        """
        Applies header styling and row colour-coding to all sheets.

        - All sheets : deep-blue header row with white bold text; auto-fit cols.
        - Recommendations sheet : rows coloured by priority (HIGH/MEDIUM/LOW).
        """
        try:
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter

            header_fill = PatternFill("solid", fgColor=_COL_HEADER)
            header_font = Font(bold=True, color=_FONT_HEADER)
            high_fill   = PatternFill("solid", fgColor=_COL_HIGH)
            med_fill    = PatternFill("solid", fgColor=_COL_MEDIUM)
            low_fill    = PatternFill("solid", fgColor=_COL_LOW)

            for sheet in workbook.worksheets:
                # ── Header row styling ────────────────────────────
                for cell in sheet[1]:
                    cell.fill      = header_fill
                    cell.font      = header_font
                    cell.alignment = Alignment(wrap_text=True)

                # ── Auto-fit column widths (capped at 60) ─────────
                for col_idx, col_cells in enumerate(sheet.columns, start=1):
                    max_len = 0
                    for cell in col_cells:
                        try:
                            max_len = max(max_len, len(str(cell.value or "")))
                        except Exception:
                            pass
                    col_letter = get_column_letter(col_idx)
                    sheet.column_dimensions[col_letter].width = min(max_len + 4, 60)

                # ── Priority colour-coding (Recommendations sheet) ─
                if sheet.title == "Recommendations":
                    header_vals = [cell.value for cell in sheet[1]]
                    if "priority" in header_vals:
                        pri_col_idx = header_vals.index("priority") + 1
                        for data_row in sheet.iter_rows(min_row=2):
                            pri_cell = data_row[pri_col_idx - 1]
                            row_fill = (
                                high_fill if pri_cell.value == "HIGH"
                                else med_fill if pri_cell.value == "MEDIUM"
                                else low_fill
                            )
                            for cell in data_row:
                                cell.fill = row_fill

        except ImportError:
            logger.warning(
                "[SparkJobOptimizer] openpyxl not available — skipping Excel formatting"
            )
        except Exception as exc:
            logger.warning("[SparkJobOptimizer] Excel formatting error (non-fatal): %s", exc)

    # ──────────────────────────────────────────────────────────────
    # Delta table write  (write_to_delta: Y)
    # ──────────────────────────────────────────────────────────────

    # Severity thresholds mirrored from SparkRecommendationEngine
    _SEVERITY_RULES: dict = {
        "skewed_jobs"         : lambda r: "HIGH" if float(r.get("skew_ratio",      0) or 0) > 10   else ("MEDIUM" if float(r.get("skew_ratio",      0) or 0) > 5    else "LOW"),
        "shuffle_spill_jobs"  : lambda r: "HIGH" if float(r.get("spill_mb",        0) or 0) > 1000 else ("MEDIUM" if float(r.get("spill_mb",        0) or 0) > 500  else "LOW"),
        "small_file_jobs"     : lambda r: "HIGH" if float(r.get("num_files",       0) or 0) > 5000 else ("MEDIUM" if float(r.get("num_files",       0) or 0) > 1000 else "LOW"),
        "broadcast_candidates": lambda r: "MEDIUM",
        "long_running_jobs"   : lambda r: "HIGH" if float(r.get("ratio_vs_threshold", 0) or 0) >= 2 else "MEDIUM",
        "failed_tasks"        : lambda r: "HIGH" if float(r.get("failure_pct",     0) or 0) > 20   else ("MEDIUM" if float(r.get("failure_pct",     0) or 0) > 5    else "LOW"),
        "delta_issues"        : lambda r: "MEDIUM" if float(r.get("days_since_last_alter", 0) or 0) > 14 else "LOW",
    }

    # Maps ScanResult attribute → category string + key metric column mappings
    # { source_col_in_raw_df: target_col_in_findings_table }
    _CATEGORY_COL_MAP: dict = {
        "skewed_jobs"         : ("data_skew",          {"job_id": "job_id",  "run_id": "run_id",  "skew_ratio": "skew_ratio"}),
        "shuffle_spill_jobs"  : ("shuffle_spill",       {"query_id": "query_id", "spill_mb": "spill_mb", "read_mb": "read_mb"}),
        "small_file_jobs"     : ("small_files",         {"table_catalog": "table_catalog", "table_schema": "table_schema", "table_name": "table_name", "num_files": "num_files"}),
        "broadcast_candidates": ("broadcast_joins",     {"query_id": "query_id", "read_mb": "read_mb"}),
        "long_running_jobs"   : ("long_running_jobs",   {"job_id": "job_id", "run_id": "run_id", "duration_mins": "duration_mins", "ratio_vs_threshold": "ratio_vs_threshold"}),
        "failed_tasks"        : ("failed_tasks",        {"job_id": "job_id", "run_id": "run_id", "failure_pct": "failure_pct"}),
        "delta_issues"        : ("delta_issues",        {"table_catalog": "table_catalog", "table_schema": "table_schema", "table_name": "table_name", "days_since_last_alter": "days_since_alter"}),
    }

    def _write_to_delta_tables(
        self,
        scan_result     : ScanResult,
        recommendations : List[OptimizationRecommendation],
        scan_id         : str,
    ) -> None:
        """
        Appends findings and recommendations to the two Unity Catalog Delta tables
        created by ``00_discovery_Setup.py``.

        Requires an active SparkSession (available automatically on Databricks).
        Skips gracefully if PySpark is not available (e.g. local unit tests).

        Tables written
        --------------
        {catalog}.{schema}.spark_job_optimizer_findings
        {catalog}.{schema}.spark_job_optimizer_recommendations
        """
        try:
            from pyspark.sql import SparkSession
            spark = SparkSession.getActiveSession()
        except ImportError:
            logger.warning(
                "[SparkJobOptimizer] PySpark not available — skipping Delta write"
            )
            return

        if spark is None:
            logger.warning(
                "[SparkJobOptimizer] No active SparkSession found — skipping Delta write. "
                "Ensure write_to_delta is only set to 'Y' when running on Databricks."
            )
            return

        catalog = self._delta_catalog
        schema  = self._delta_schema
        findings_table = f"{catalog}.{schema}.spark_job_optimizer_findings"
        recs_table     = f"{catalog}.{schema}.spark_job_optimizer_recommendations"

        # ── Build unified findings DataFrame ────────────────────
        all_finding_rows = []
        for attr, (category, col_map) in self._CATEGORY_COL_MAP.items():
            raw_df = getattr(scan_result, attr, pd.DataFrame())
            if raw_df.empty:
                continue

            severity_fn = self._SEVERITY_RULES[attr]

            for _, row in raw_df.iterrows():
                row_dict = row.to_dict()
                finding_row = {
                    "finding_id"         : str(uuid.uuid4()),
                    "scan_id"            : scan_id,
                    "workspace_id"       : scan_result.workspace_id,
                    "workspace_name"     : scan_result.workspace_name,
                    "scan_timestamp"     : scan_result.scan_timestamp,
                    "lookback_days"      : scan_result.lookback_days,
                    "category"           : category,
                    "severity"           : severity_fn(row_dict),
                    # source identifiers
                    "job_id"             : str(row_dict.get("job_id",  "") or ""),
                    "run_id"             : str(row_dict.get("run_id",  "") or ""),
                    "query_id"           : str(row_dict.get("query_id","") or ""),
                    # table reference
                    "table_catalog"      : str(row_dict.get("table_catalog","") or ""),
                    "table_schema"       : str(row_dict.get("table_schema", "") or ""),
                    "table_name"         : str(row_dict.get("table_name",   "") or ""),
                    # key metrics (nullable per category)
                    "skew_ratio"         : self._safe_float(row_dict.get("skew_ratio")),
                    "spill_mb"           : self._safe_float(row_dict.get("spill_mb")),
                    "read_mb"            : self._safe_float(row_dict.get("read_mb")),
                    "num_files"          : self._safe_bigint(row_dict.get("num_files")),
                    "duration_mins"      : self._safe_float(row_dict.get("duration_mins")),
                    "failure_pct"        : self._safe_float(row_dict.get("failure_pct")),
                    "days_since_alter"   : self._safe_int(row_dict.get("days_since_last_alter")),
                    # full row as JSON for drilldown
                    "details_json"       : json.dumps(
                        {k: str(v) for k, v in row_dict.items()}, default=str
                    ),
                }
                all_finding_rows.append(finding_row)

        if all_finding_rows:
            findings_pd = pd.DataFrame(all_finding_rows)
            findings_sdf = spark.createDataFrame(findings_pd)
            (
                findings_sdf.write
                .format("delta")
                .mode("append")
                .option("mergeSchema", "true")
                .saveAsTable(findings_table)
            )
            logger.info(
                "[SparkJobOptimizer] Wrote %d finding rows → %s",
                len(all_finding_rows), findings_table,
            )
        else:
            logger.info("[SparkJobOptimizer] No findings to write to Delta")

        # ── Build recommendations DataFrame ─────────────────────
        if recommendations:
            rec_rows = [
                {
                    "recommendation_id": r.recommendation_id,
                    "scan_id"          : scan_id,
                    "workspace_id"     : scan_result.workspace_id,
                    "scan_timestamp"   : scan_result.scan_timestamp,
                    "finding_id"       : r.finding_id,
                    "category"         : r.category,
                    "priority"         : r.priority,
                    "issue_summary"    : r.issue_summary,
                    "actions"          : "\n".join(r.actions),
                    "sql_scripts"      : "\n\n".join(r.sql_scripts),
                    "estimated_savings": r.estimated_savings,
                    "reference_docs"   : "\n".join(r.reference_docs),
                }
                for r in recommendations
            ]
            recs_pd  = pd.DataFrame(rec_rows)
            recs_sdf = spark.createDataFrame(recs_pd)
            (
                recs_sdf.write
                .format("delta")
                .mode("append")
                .option("mergeSchema", "true")
                .saveAsTable(recs_table)
            )
            logger.info(
                "[SparkJobOptimizer] Wrote %d recommendation rows → %s",
                len(rec_rows), recs_table,
            )

    # ──────────────────────────────────────────────────────────────
    # CSV export
    # ──────────────────────────────────────────────────────────────

    def _export_csv(self, scan_result: ScanResult, csv_dir: str) -> None:
        """
        Exports each non-empty finding DataFrame to a separate CSV file.
        Files are written to ``csv_dir`` with a timestamp suffix.
        """
        os.makedirs(csv_dir, exist_ok=True)
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        ws = scan_result.workspace_id.replace("/", "_").replace(":", "")

        for attr, sheet_name in self._SHEET_MAP.items():
            df = getattr(scan_result, attr, pd.DataFrame())
            if not df.empty:
                fname = f"{ws}_{sheet_name}_{ts}.csv"
                fpath = os.path.join(csv_dir, fname)
                df.to_csv(fpath, index=False)
                logger.info("[SparkJobOptimizer] CSV exported: %s", fpath)

    # ──────────────────────────────────────────────────────────────
    # Type-coercion helpers
    # ──────────────────────────────────────────────────────────────

    @staticmethod
    def _safe_float(val) -> Optional[float]:
        try:
            return float(val) if val is not None and str(val).strip() != "" else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _safe_int(val) -> Optional[int]:
        try:
            return int(float(val)) if val is not None and str(val).strip() != "" else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _safe_bigint(val) -> Optional[int]:
        try:
            return int(float(val)) if val is not None and str(val).strip() != "" else None
        except (TypeError, ValueError):
            return None
