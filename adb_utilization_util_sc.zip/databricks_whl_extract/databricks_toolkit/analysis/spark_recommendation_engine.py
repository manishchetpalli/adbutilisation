"""
SparkRecommendationEngine — Class 3 (Plugin 1).

Maps ``ScanResult`` findings to ``OptimizationRecommendation`` objects.
Each per-category method applies rule-based priority logic and auto-generates
ready-to-run SQL scripts where applicable.

Priority rules (from plugin spec)
----------------------------------
| Category          | HIGH threshold          | MEDIUM threshold        |
|-------------------|-------------------------|-------------------------|
| Data Skew         | skew_ratio > 10         | skew_ratio > 5          |
| Shuffle Spill     | spill_mb > 1000         | spill_mb > 500          |
| Small Files       | file_count > 5000       | file_count > 1000       |
| Broadcast Joins   | always MEDIUM           | —                       |
| Long Running Jobs | ratio_vs_threshold >= 2 | ratio_vs_threshold >= 1 |
| Failed Tasks      | failure_pct > 20        | failure_pct > 5         |
| Delta Issues      | days_since_alter > 14   | days_since_alter > 7    |
"""

import logging
import uuid
from typing import List

import pandas as pd

from ..models.spark_optimizer_models import (
    OptimizationFinding,
    OptimizationRecommendation,
    ScanResult,
)

logger = logging.getLogger(__name__)

# ── Databricks documentation cross-references ────────────────────────────────
_DOCS: dict = {
    "data_skew"        : "https://docs.databricks.com/en/optimizations/skew-join.html",
    "shuffle_spill"    : "https://docs.databricks.com/en/optimizations/aqe.html",
    "small_files"      : "https://docs.databricks.com/en/delta/optimize.html",
    "broadcast_joins"  : "https://docs.databricks.com/en/delta/join-performance.html",
    "long_running_jobs": "https://docs.databricks.com/en/jobs/azure-databricks-clusters-best-practices.html",
    "failed_tasks"     : "https://docs.databricks.com/en/clusters/configure.html",
    "delta_issues"     : "https://docs.databricks.com/en/delta/vacuum.html",
}


class SparkRecommendationEngine:
    """
    Rule-based engine that maps ScanResult findings to a list of
    ``OptimizationRecommendation`` dataclasses.

    Parameters
    ----------
    config : Plugin configuration dict containing
             ``spark_job_optimizer.thresholds``.
    """

    def __init__(self, config: dict):
        plugin_cfg        = config.get("spark_job_optimizer", {}) if isinstance(config, dict) else {}
        self._thresholds  = plugin_cfg.get("thresholds", {})

    # ──────────────────────────────────────────────────────────────
    # Class 3 — Public API
    # ──────────────────────────────────────────────────────────────

    def generate_recommendations(
        self, scan_result: ScanResult
    ) -> List[OptimizationRecommendation]:
        """
        Master method — processes all finding categories and returns a flat
        list of ``OptimizationRecommendation`` objects.

        Parameters
        ----------
        scan_result : Populated ``ScanResult`` from ``SparkJobOptimizerScanner``.

        Returns
        -------
        list[OptimizationRecommendation]
        """
        recs: List[OptimizationRecommendation] = []
        recs.extend(self._recommend_for_skew(scan_result.skewed_jobs))
        recs.extend(self._recommend_for_shuffle(scan_result.shuffle_spill_jobs))
        recs.extend(self._recommend_for_small_files(scan_result.small_file_jobs))
        recs.extend(self._recommend_for_broadcast(scan_result.broadcast_candidates))
        recs.extend(self._recommend_for_long_jobs(scan_result.long_running_jobs))
        recs.extend(self._recommend_for_failed_tasks(scan_result.failed_tasks))
        recs.extend(self._recommend_for_delta(scan_result.delta_issues))
        logger.info(
            "[RecommendationEngine] Generated %d recommendations", len(recs)
        )
        return recs

    # ──────────────────────────────────────────────────────────────
    # Per-category recommendation methods
    # ──────────────────────────────────────────────────────────────

    def _recommend_for_skew(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """AQE hints, SKEW HINT SQL, repartition suggestions."""
        out = []
        for _, row in df.iterrows():
            ratio    = self._to_float(row.get("skew_ratio", 0))
            job_id   = str(row.get("job_id", "unknown"))
            run_id   = str(row.get("run_id", "unknown"))
            priority = "HIGH" if ratio > 10 else "MEDIUM"

            sql_hint = (
                f"-- Job {job_id}: apply skew join hint to the skewed column\n"
                "SELECT /*+ SKEW('large_table', 'skewed_column') */\n"
                "       l.*, r.*\n"
                "FROM   large_table l\n"
                "JOIN   other_table r ON l.skewed_column = r.key;"
            )
            aqe_config = (
                "-- Enable Adaptive Query Execution (cluster or notebook level)\n"
                "SET spark.sql.adaptive.enabled = true;\n"
                "SET spark.sql.adaptive.skewJoin.enabled = true;\n"
                "SET spark.sql.adaptive.skewJoin.skewedPartitionFactor = 5;"
            )
            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"skew-{job_id}-{run_id}",
                category          = "data_skew",
                issue_summary     = (
                    f"Job {job_id} / run {run_id} has a data skew ratio of "
                    f"{ratio:.1f}x (longest task >> median task duration)."
                ),
                actions           = [
                    "Enable AQE skew-join optimization: spark.sql.adaptive.skewJoin.enabled=true",
                    "Apply SKEW hint directly in the SQL query for the skewed column",
                    "Consider salting the skewed join key to distribute data uniformly",
                    "Use repartition() or repartitionByRange() to pre-balance data before joins",
                    "Review input data distribution — filter or pre-aggregate before the join",
                ],
                sql_scripts       = [aqe_config, sql_hint],
                priority          = priority,
                estimated_savings = "15–40% reduction in overall job duration",
                reference_docs    = [_DOCS["data_skew"]],
            ))
        return out

    def _recommend_for_shuffle(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Executor memory tuning, partition reduction recommendations."""
        out = []
        threshold = float(self._thresholds.get("shuffle_spill_mb", 500))
        for _, row in df.iterrows():
            spill_mb = self._to_float(row.get("spill_mb", 0))
            qid      = str(row.get("query_id", "unknown"))
            priority = "HIGH" if spill_mb > 1000 else "MEDIUM"

            config_snip = (
                "-- Add to cluster Spark config or notebook init cell\n"
                "spark.conf.set('spark.executor.memory', '8g')\n"
                "spark.conf.set('spark.executor.memoryFraction', '0.8')\n"
                "spark.conf.set('spark.sql.shuffle.partitions', '400')\n"
                "spark.conf.set('spark.sql.adaptive.enabled', 'true')\n"
                "spark.conf.set('spark.sql.adaptive.coalescePartitions.enabled', 'true')"
            )
            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"spill-{qid}",
                category          = "shuffle_spill",
                issue_summary     = (
                    f"Query {qid} spilled {spill_mb:.0f} MB to disk "
                    f"(threshold: {threshold:.0f} MB) — indicates memory pressure "
                    "during shuffle."
                ),
                actions           = [
                    "Increase executor memory allocation on the job cluster",
                    "Reduce spark.sql.shuffle.partitions to lower per-partition memory overhead",
                    "Enable AQE coalesce partitions to avoid oversized shuffle stages",
                    "Check for Cartesian products or unbounded cross-joins in the query plan",
                    "Consider using Delta caching to reduce repeated shuffle reads",
                ],
                sql_scripts       = [config_snip],
                priority          = priority,
                estimated_savings = "20–50% reduction in query duration; eliminates disk I/O stall",
                reference_docs    = [_DOCS["shuffle_spill"]],
            ))
        return out

    def _recommend_for_small_files(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Auto-generates OPTIMIZE SQL per affected table."""
        out = []
        threshold = int(self._thresholds.get("small_file_count", 1000))
        for _, row in df.iterrows():
            catalog   = str(row.get("table_catalog", ""))
            schema    = str(row.get("table_schema", ""))
            table     = str(row.get("table_name", ""))
            fqn       = f"{catalog}.{schema}.{table}"
            num_files = row.get("num_files", 0)
            priority  = "HIGH" if int(num_files or 0) > 5000 else "MEDIUM"

            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"smallfiles-{fqn}",
                category          = "small_files",
                issue_summary     = (
                    f"Table {fqn} has {num_files} small files "
                    f"(threshold: {threshold}). Excessive small files degrade "
                    "read performance and increase planning overhead."
                ),
                actions           = [
                    f"Run OPTIMIZE on {fqn} to compact small Delta files",
                    "Enable Auto-Optimize on the table to prevent future small-file accumulation",
                    "Review write patterns — avoid many small appends; batch writes where possible",
                    "Consider ZORDER by the most frequently queried predicate columns",
                    "Schedule periodic OPTIMIZE in a maintenance job (daily or weekly)",
                ],
                sql_scripts       = [
                    f"-- Compact small files\nOPTIMIZE {fqn};",
                    (
                        f"-- Enable auto-optimize to prevent recurrence\n"
                        f"ALTER TABLE {fqn} SET TBLPROPERTIES (\n"
                        f"  'delta.autoOptimize.optimizeWrite' = 'true',\n"
                        f"  'delta.autoOptimize.autoCompact'   = 'true'\n"
                        f");"
                    ),
                ],
                priority          = priority,
                estimated_savings = "30–60% improvement in scan / read latency",
                reference_docs    = [_DOCS["small_files"]],
            ))
        return out

    def _recommend_for_broadcast(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Generates broadcast hint SQL for eligible queries."""
        out = []
        threshold_mb = float(self._thresholds.get("broadcast_threshold_mb", 200))
        for _, row in df.iterrows():
            qid     = str(row.get("query_id", "unknown"))
            read_mb = self._to_float(row.get("read_mb", 0))

            sql_hint = (
                f"-- Query {qid}: replace shuffle join with broadcast join\n"
                "-- Apply BROADCAST hint to the SMALLER table in the join\n"
                "SELECT /*+ BROADCAST(small_dim) */\n"
                "       f.*, small_dim.*\n"
                "FROM   fact_table        f\n"
                "JOIN   small_dim_table   small_dim\n"
                "  ON   f.dim_key = small_dim.key;"
            )
            aqe_config = (
                "-- Alternatively, raise the auto-broadcast threshold\n"
                "SET spark.sql.autoBroadcastJoinThreshold = 209715200;  -- 200 MB\n"
                "SET spark.sql.adaptive.enabled = true;  -- AQE can also pick broadcast at runtime"
            )
            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"broadcast-{qid}",
                category          = "broadcast_joins",
                issue_summary     = (
                    f"Query {qid} reads {read_mb:.0f} MB and performs a shuffle "
                    f"join on data smaller than the broadcast threshold "
                    f"({threshold_mb:.0f} MB). Converting to a broadcast join "
                    "will eliminate the shuffle stage."
                ),
                actions           = [
                    "Add a BROADCAST hint to the smaller table in the join",
                    "Raise spark.sql.autoBroadcastJoinThreshold to cover the table size",
                    "Enable AQE — it can convert eligible joins to broadcast at runtime",
                    "Verify the smaller table fits in executor memory before broadcasting",
                ],
                sql_scripts       = [sql_hint, aqe_config],
                priority          = "MEDIUM",
                estimated_savings = "10–35% reduction in shuffle network I/O and stage duration",
                reference_docs    = [_DOCS["broadcast_joins"]],
            ))
        return out

    def _recommend_for_long_jobs(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Cluster sizing, autoscaling policy suggestions."""
        out = []
        threshold = float(self._thresholds.get("job_duration_p95_mins", 60))
        for _, row in df.iterrows():
            job_id   = str(row.get("job_id", "unknown"))
            run_id   = str(row.get("run_id", "unknown"))
            dur_mins = self._to_float(row.get("duration_mins", 0))
            ratio    = self._to_float(row.get("ratio_vs_threshold", dur_mins / max(threshold, 0.001)))
            priority = "HIGH" if ratio >= 2.0 else "MEDIUM"

            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"longjob-{job_id}-{run_id}",
                category          = "long_running_jobs",
                issue_summary     = (
                    f"Job {job_id} / run {run_id} ran for {dur_mins:.1f} min "
                    f"({ratio:.1f}x the {threshold:.0f}-min P95 threshold)."
                ),
                actions           = [
                    "Profile the job using Spark UI — identify the slowest stage/task",
                    "Check for data skew, small files, or excessive shuffle in the execution plan",
                    "Review cluster sizing — add workers or upgrade to a memory-optimised node type",
                    "Enable autoscaling with an appropriate min/max worker range",
                    "Split large monolithic jobs into smaller, independently schedulable tasks",
                    "Avoid peak-resource scheduling windows; distribute load across the day",
                ],
                sql_scripts       = [],
                priority          = priority,
                estimated_savings = "20–50% reduction in wall-clock job time",
                reference_docs    = [_DOCS["long_running_jobs"]],
            ))
        return out

    def _recommend_for_failed_tasks(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Retry policy config, executor memory tuning."""
        out = []
        threshold = float(self._thresholds.get("failed_task_pct", 5.0))
        for _, row in df.iterrows():
            job_id   = str(row.get("job_id", "unknown"))
            run_id   = str(row.get("run_id", "unknown"))
            fail_pct = self._to_float(row.get("failure_pct", 0))
            priority = "HIGH" if fail_pct > 20 else "MEDIUM"

            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"failedtask-{job_id}-{run_id}",
                category          = "failed_tasks",
                issue_summary     = (
                    f"Job {job_id} / run {run_id} recorded a {fail_pct:.1f}% "
                    f"task failure rate (threshold: {threshold:.0f}%)."
                ),
                actions           = [
                    "Inspect task failure logs in the Spark UI for OOM / timeout / data errors",
                    "Increase executor memory to prevent Out-Of-Memory (OOM) task failures",
                    "Configure task-level retries: maxRetries and retryOnTimeout in job settings",
                    "Validate source data integrity — check for corrupt or missing files",
                    "Avoid spot/preemptible instances for tasks that cannot be interrupted",
                    "Add input data validation or schema enforcement upstream",
                ],
                sql_scripts       = [],
                priority          = priority,
                estimated_savings = "Improved reliability; eliminates costly full job re-runs",
                reference_docs    = [_DOCS["failed_tasks"]],
            ))
        return out

    def _recommend_for_delta(
        self, df: pd.DataFrame
    ) -> List[OptimizationRecommendation]:
        """Auto-generates OPTIMIZE + VACUUM + ZORDER SQL scripts."""
        out = []
        threshold = int(self._thresholds.get("days_since_optimize", 7))
        for _, row in df.iterrows():
            catalog  = str(row.get("table_catalog", ""))
            schema   = str(row.get("table_schema", ""))
            table    = str(row.get("table_name", ""))
            fqn      = f"{catalog}.{schema}.{table}"
            days_old = int(self._to_float(row.get("days_since_last_alter", 0)))
            priority = "MEDIUM" if days_old > 14 else "LOW"

            out.append(OptimizationRecommendation(
                recommendation_id = str(uuid.uuid4()),
                finding_id        = f"delta-{fqn}",
                category          = "delta_issues",
                issue_summary     = (
                    f"Delta table {fqn} has not been optimized for {days_old} day(s) "
                    f"(threshold: {threshold} days). Stale Delta tables accumulate "
                    "obsolete file versions and degrade query performance."
                ),
                actions           = [
                    f"Run OPTIMIZE on {fqn} to compact Delta log files",
                    f"Run VACUUM on {fqn} to remove file versions older than 7 days",
                    "Add ZORDER BY on the highest-cardinality predicate column to speed up reads",
                    "Enable Predictive Optimization in Unity Catalog to automate maintenance",
                    "Schedule weekly OPTIMIZE + VACUUM in a dedicated maintenance job",
                ],
                sql_scripts       = [
                    f"-- Compact Delta files\nOPTIMIZE {fqn};",
                    f"-- Remove obsolete file versions (retain 7 days for time-travel)\nVACUUM {fqn} RETAIN 168 HOURS;",
                    (
                        f"-- Optional: ZORDER by most-queried column for better data skipping\n"
                        f"-- Replace <partition_col> with the actual column name\n"
                        f"OPTIMIZE {fqn} ZORDER BY (<partition_col>);"
                    ),
                ],
                priority          = priority,
                estimated_savings = "10–40% improvement in query scan performance",
                reference_docs    = [_DOCS["delta_issues"]],
            ))
        return out

    # ──────────────────────────────────────────────────────────────
    # Utility methods
    # ──────────────────────────────────────────────────────────────

    def _assign_priority(self, finding: OptimizationFinding) -> str:
        """
        Returns HIGH / MEDIUM / LOW based on the ratio of the measured
        metric value against the configured threshold.
        """
        ratio = finding.metric_value / max(finding.threshold_value, 1e-9)
        if ratio >= 2.0:
            return "HIGH"
        if ratio >= 1.0:
            return "MEDIUM"
        return "LOW"

    def _get_docs_link(self, category: str) -> str:
        """Returns the Databricks documentation URL for the given category."""
        return _DOCS.get(category, "https://docs.databricks.com/")

    @staticmethod
    def _to_float(value) -> float:
        """Safely converts a value to float; returns 0.0 on failure."""
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0
