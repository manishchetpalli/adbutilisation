"""
SparkJobOptimizerScanner — Class 1 (Plugin 1, Tier 3).

Entry point for all Spark optimization scans.  Queries **read-only**
Databricks system tables and returns a ``ScanResult`` dataclass populated
with seven pandas DataFrames — one per detection category.

Execution characteristics
-------------------------
- Tier   : 3 (sequential, 1 worker)
- Mode   : Deep scan only
- Source : Databricks system tables (Unity Catalog required)
- Output : ``ScanResult`` passed to ``SparkJobOptimizerAnalyzer``

System tables used
------------------
- ``system.lakeflow.job_task_run_timeline`` — data skew + failed tasks
- ``system.query.history``               — shuffle spill + broadcast joins
- ``system.lakeflow.job_run_timeline``   — long-running jobs
- ``system.information_schema.tables``   — small files + Delta issues
- ``system.information_schema.table_properties`` — Delta file counts
"""

import concurrent.futures
import logging
from datetime import datetime
from typing import Callable, Dict, List, Optional

import pandas as pd
from databricks.sdk import WorkspaceClient

from ..models.spark_optimizer_models import ScanResult
from ..utils.query_executor import QueryExecutor

logger = logging.getLogger(__name__)


class SparkJobOptimizerScanner:
    """
    Tier-3 scanner that detects Spark job inefficiencies using system tables.

    Parameters
    ----------
    client : Authenticated ``databricks.sdk.WorkspaceClient``.
    config : ``ScanConfig`` instance **or** plain ``dict`` — the scanner
             reads the ``spark_job_optimizer`` key for plugin-specific
             settings (thresholds, warehouse_id, lookback_days).
    """

    # Default thresholds — overridden by the ``spark_job_optimizer.thresholds``
    # block in ``config.json`` / ``ScanConfig``.
    _DEFAULT_THRESHOLDS: dict = {
        "skew_ratio"             : 5.0,
        "shuffle_spill_mb"       : 500,
        "small_file_count"       : 1000,
        "broadcast_threshold_mb" : 200,
        "job_duration_p95_mins"  : 60,
        "failed_task_pct"        : 5.0,
        "days_since_optimize"    : 7,
    }

    def __init__(self, client: WorkspaceClient, config):
        self.client = client

        # Support both ScanConfig dataclass and plain dict
        if isinstance(config, dict):
            plugin_cfg = config.get("spark_job_optimizer", {})
        else:
            plugin_cfg = getattr(config, "spark_job_optimizer", {}) or {}

        self._plugin_cfg  = plugin_cfg if isinstance(plugin_cfg, dict) else {}
        self._thresholds  = {
            **self._DEFAULT_THRESHOLDS,
            **self._plugin_cfg.get("thresholds", {}),
        }
        self._lookback    : int              = int(self._plugin_cfg.get("lookback_days", 30))
        self._executor    : Optional[QueryExecutor] = None  # lazy init in scan()

    # ──────────────────────────────────────────────────────────────
    # Class 1 — Public API
    # ──────────────────────────────────────────────────────────────

    def scan(self) -> ScanResult:
        """
        Master orchestrator — calls all seven detection methods sequentially
        and returns a fully-populated ``ScanResult``.

        Returns
        -------
        ScanResult
        """
        warehouse_id   = self._get_warehouse_id()
        self._executor = QueryExecutor(self.client, warehouse_id)
        workspace_id   = self._get_workspace_id()
        workspace_name = self._get_workspace_name()

        logger.info(
            "[SparkJobOptimizer] Starting deep scan | workspace=%s | lookback=%dd",
            workspace_id,
            self._lookback,
        )

        # Run all 7 detections in parallel (max 3 concurrent) — same pattern
        # as UnityCatalogScanner._scan_tables_parallel().
        detections = [
            ("data_skew",         self._detect_data_skew),
            ("shuffle_spill",     self._detect_shuffle_spill),
            ("small_files",       self._detect_small_files),
            ("broadcast_joins",   self._detect_broadcast_joins),
            ("long_running_jobs", self._detect_long_running_jobs),
            ("failed_tasks",      self._detect_failed_tasks),
            ("delta_issues",      self._detect_delta_issues),
        ]
        detection_results: Dict[str, pd.DataFrame] = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            future_to_name = {
                executor.submit(self._safe_detect, name, fn): name
                for name, fn in detections
            }
            completed = 0
            for future in concurrent.futures.as_completed(future_to_name):
                name = future_to_name[future]
                detection_results[name] = future.result()
                completed += 1
                logger.info(
                    "[SparkJobOptimizer] Detection '%s' complete: %d rows (%d/7)",
                    name, len(detection_results[name]), completed,
                )

        skewed_jobs          = detection_results["data_skew"]
        shuffle_spill_jobs   = detection_results["shuffle_spill"]
        small_file_jobs      = detection_results["small_files"]
        broadcast_candidates = detection_results["broadcast_joins"]
        long_running_jobs    = detection_results["long_running_jobs"]
        failed_tasks         = detection_results["failed_tasks"]
        delta_issues         = detection_results["delta_issues"]

        result = ScanResult(
            workspace_id         = workspace_id,
            workspace_name       = workspace_name,
            scan_timestamp       = datetime.utcnow(),
            scan_mode            = "deep",
            lookback_days        = self._lookback,
            skewed_jobs          = skewed_jobs,
            shuffle_spill_jobs   = shuffle_spill_jobs,
            small_file_jobs      = small_file_jobs,
            broadcast_candidates = broadcast_candidates,
            long_running_jobs    = long_running_jobs,
            failed_tasks         = failed_tasks,
            delta_issues         = delta_issues,
        )

        logger.info(
            "[SparkJobOptimizer] Scan complete — total findings: %d",
            result.total_findings,
        )
        return result

    # ──────────────────────────────────────────────────────────────
    # Detection method 1 — Data Skew
    # Source: system.lakeflow.job_task_run_timeline
    # ──────────────────────────────────────────────────────────────

    def _detect_data_skew(self) -> pd.DataFrame:
        """
        Finds jobs where the longest task duration is significantly greater
        than the median (skew_ratio = max_task_ms / median_task_ms).

        Returns rows where skew_ratio exceeds the configured threshold.
        """
        skew_ratio = float(self._thresholds["skew_ratio"])
        # Correct table: system.lakeflow.job_task_run_timeline
        # Correct columns: period_start_time / period_end_time
        # (system.compute.task_run_timeline does not exist in all workspaces)
        query = f"""
        SELECT
            job_id,
            run_id,
            COUNT(*)                                                               AS total_tasks,
            ROUND(MAX(
                TIMESTAMPDIFF(MILLISECOND, period_start_time, period_end_time)
            ), 0)                                                                  AS max_task_ms,
            ROUND(PERCENTILE_APPROX(
                TIMESTAMPDIFF(MILLISECOND, period_start_time, period_end_time), 0.5
            ), 0)                                                                  AS median_task_ms,
            ROUND(
                MAX(TIMESTAMPDIFF(MILLISECOND, period_start_time, period_end_time))
                / NULLIF(PERCENTILE_APPROX(
                    TIMESTAMPDIFF(MILLISECOND, period_start_time, period_end_time), 0.5
                ), 0),
            2)                                                                     AS skew_ratio
        FROM system.lakeflow.job_task_run_timeline
        WHERE period_start_time >= NOW() - INTERVAL {self._lookback} DAYS
          AND job_id             IS NOT NULL
          AND period_end_time    IS NOT NULL
        GROUP BY job_id, run_id
        HAVING skew_ratio > {skew_ratio}
        ORDER BY skew_ratio DESC
        LIMIT 500
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Data skew findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 2 — Shuffle Spill
    # Source: system.query.history
    # ──────────────────────────────────────────────────────────────

    def _detect_shuffle_spill(self) -> pd.DataFrame:
        """
        Identifies queries with disk spill above the configured threshold,
        indicating memory pressure during shuffle operations.
        """
        spill_mb = float(self._thresholds["shuffle_spill_mb"])
        query = f"""
        SELECT
            statement_id                                          AS query_id,
            executed_by,
            statement_type,
            start_time,
            end_time,
            ROUND(spilled_local_bytes  / 1048576.0, 2)           AS spill_mb,
            ROUND(read_bytes           / 1048576.0, 2)           AS read_mb,
            ROUND(written_bytes        / 1048576.0, 2)           AS write_mb,
            total_task_duration_ms,
            read_rows,
            produced_rows
        FROM system.query.history
        WHERE start_time              >= NOW() - INTERVAL {self._lookback} DAYS
          AND spilled_local_bytes      IS NOT NULL
          AND spilled_local_bytes / 1048576.0 > {spill_mb}
        ORDER BY spill_mb DESC
        LIMIT 500
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Shuffle spill findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 3 — Small Files
    # Source: system.information_schema.tables +
    #         system.information_schema.table_properties
    # ──────────────────────────────────────────────────────────────

    def _detect_small_files(self) -> pd.DataFrame:
        """
        Identifies Delta tables whose recorded ``delta.numFiles`` property
        exceeds the configured ``small_file_count`` threshold.
        """
        file_count = int(self._thresholds["small_file_count"])
        days       = int(self._thresholds["days_since_optimize"])
        query = f"""
        SELECT
            t.table_catalog,
            t.table_schema,
            t.table_name,
            t.table_type,
            t.data_source_format,
            t.last_altered,
            DATEDIFF(NOW(), t.last_altered)    AS days_since_last_alter,
            t.table_owner,
            CAST(tp.property_value AS BIGINT)  AS num_files
        FROM system.information_schema.tables t
        JOIN system.information_schema.table_properties tp
          ON  t.table_catalog  = tp.table_catalog
          AND t.table_schema   = tp.table_schema
          AND t.table_name     = tp.table_name
          AND tp.property_name = 'delta.numFiles'
        WHERE t.data_source_format = 'DELTA'
          AND TRY_CAST(tp.property_value AS BIGINT) > {file_count}
          AND DATEDIFF(NOW(), t.last_altered) > {days}
        ORDER BY num_files DESC
        LIMIT 200
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Small file findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 4 — Broadcast Join Candidates
    # Source: system.query.history
    # ──────────────────────────────────────────────────────────────

    def _detect_broadcast_joins(self) -> pd.DataFrame:
        """
        Identifies queries that perform shuffle joins on datasets smaller than
        the broadcast threshold — these could be converted to broadcast joins.
        """
        threshold_mb = float(self._thresholds["broadcast_threshold_mb"])
        query = f"""
        SELECT
            statement_id                                                   AS query_id,
            executed_by,
            statement_type,
            start_time,
            end_time,
            ROUND(read_bytes           / 1048576.0, 2)                    AS read_mb,
            ROUND(shuffle_local_bytes  / 1048576.0, 2)                    AS shuffle_local_mb,
            ROUND(shuffle_remote_bytes / 1048576.0, 2)                    AS shuffle_remote_mb,
            total_task_duration_ms,
            read_rows,
            SUBSTRING(statement_text, 1, 500)                             AS statement_preview
        FROM system.query.history
        WHERE start_time >= NOW() - INTERVAL {self._lookback} DAYS
          AND statement_type IN ('SELECT', 'DML')
          AND read_bytes IS NOT NULL
          AND read_bytes / 1048576.0 BETWEEN 1 AND {threshold_mb}
          AND (
              COALESCE(shuffle_local_bytes, 0)
              + COALESCE(shuffle_remote_bytes, 0)
          ) > 0
          AND (
              statement_text IS NULL
              OR (
                  LOWER(statement_text) NOT LIKE '%broadcast%'
                  AND LOWER(statement_text) NOT LIKE '% /*+%'
              )
          )
        ORDER BY (COALESCE(shuffle_local_bytes, 0) + COALESCE(shuffle_remote_bytes, 0)) DESC
        LIMIT 300
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Broadcast join candidates: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 5 — Long-Running Jobs
    # Source: system.lakeflow.job_run_timeline
    # Columns: period_start_time / period_end_time / result_state
    # ──────────────────────────────────────────────────────────────

    def _detect_long_running_jobs(self) -> pd.DataFrame:
        """
        Identifies job runs whose wall-clock duration exceeds the configured
        P95 threshold (``job_duration_p95_mins``).
        """
        p95_mins = float(self._thresholds["job_duration_p95_mins"])
        p95_secs = p95_mins * 60.0
        # system.lakeflow.job_run_timeline — confirmed column names:
        # period_start_time / period_end_time  (same convention as job_task_run_timeline)
        # result_state (values: SUCCEEDED / FAILED / null)
        query = f"""
        WITH durations AS (
            SELECT
                job_id,
                run_id,
                result_state,
                period_start_time                                                      AS start_time,
                period_end_time                                                        AS end_time,
                TIMESTAMPDIFF(SECOND, period_start_time, period_end_time)             AS duration_secs
            FROM system.lakeflow.job_run_timeline
            WHERE period_start_time >= NOW() - INTERVAL {self._lookback} DAYS
              AND period_end_time    IS NOT NULL
              AND period_start_time  IS NOT NULL
        )
        SELECT
            job_id,
            run_id,
            result_state,
            start_time,
            end_time,
            ROUND(duration_secs / 60.0,              2)  AS duration_mins,
            ROUND(duration_secs / 60.0 / {p95_mins}, 2)  AS ratio_vs_threshold
        FROM durations
        WHERE duration_secs > {p95_secs}
        ORDER BY duration_secs DESC
        LIMIT 300
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Long-running job findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 6 — Failed Tasks
    # Source: system.lakeflow.job_task_run_timeline
    # ──────────────────────────────────────────────────────────────

    def _detect_failed_tasks(self) -> pd.DataFrame:
        """
        Identifies job runs where the percentage of failed tasks exceeds
        the configured ``failed_task_pct`` threshold.
        """
        failed_pct = float(self._thresholds["failed_task_pct"])
        # Correct table: system.lakeflow.job_task_run_timeline
        # Correct status column: result_state (values: SUCCEEDED / FAILED / null)
        # (system.compute.task_run_timeline does not exist in all workspaces)
        query = f"""
        SELECT
            job_id,
            run_id,
            COUNT(*)                                                                   AS total_tasks,
            SUM(CASE WHEN result_state = 'FAILED' THEN 1 ELSE 0 END)                  AS failed_tasks,
            ROUND(
                100.0 * SUM(CASE WHEN result_state = 'FAILED' THEN 1 ELSE 0 END)
                / NULLIF(COUNT(*), 0),
            2)                                                                         AS failure_pct
        FROM system.lakeflow.job_task_run_timeline
        WHERE period_start_time >= NOW() - INTERVAL {self._lookback} DAYS
          AND job_id              IS NOT NULL
        GROUP BY job_id, run_id
        HAVING failure_pct > {failed_pct}
        ORDER BY failure_pct DESC
        LIMIT 300
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Failed task findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Detection method 7 — Delta Table Issues
    # Source: system.information_schema.tables
    # ──────────────────────────────────────────────────────────────

    def _detect_delta_issues(self) -> pd.DataFrame:
        """
        Identifies Delta tables that have not been modified (and therefore
        likely not optimized) within the configured ``days_since_optimize``
        window.
        """
        days_since = int(self._thresholds["days_since_optimize"])
        query = f"""
        SELECT
            table_catalog,
            table_schema,
            table_name,
            table_type,
            data_source_format,
            created,
            last_altered,
            DATEDIFF(NOW(), last_altered)                                       AS days_since_last_alter,
            table_owner,
            comment,
            CASE
                WHEN DATEDIFF(NOW(), last_altered) > 90
                    THEN CONCAT('CRITICAL: Delta table not OPTIMIZE/VACUUM''d in ',
                                CAST(DATEDIFF(NOW(), last_altered) AS STRING),
                                ' days (>90) — high read-amplification risk')
                WHEN DATEDIFF(NOW(), last_altered) > 30
                    THEN CONCAT('WARNING: Delta table not OPTIMIZE/VACUUM''d in ',
                                CAST(DATEDIFF(NOW(), last_altered) AS STRING),
                                ' days (>30) — small-file accumulation likely')
                ELSE
                    CONCAT('INFO: Delta table not OPTIMIZE/VACUUM''d in ',
                           CAST(DATEDIFF(NOW(), last_altered) AS STRING),
                           ' days (threshold: {days_since} days)')
            END                                                                 AS issue_description,
            CONCAT(
                'OPTIMIZE `', table_catalog, '`.`', table_schema, '`.`', table_name, '`; ',
                'VACUUM `',   table_catalog, '`.`', table_schema, '`.`', table_name,
                '` RETAIN 168 HOURS;'
            )                                                                   AS recommended_sql
        FROM system.information_schema.tables
        WHERE data_source_format = 'DELTA'
          AND DATEDIFF(NOW(), last_altered) > {days_since}
        ORDER BY days_since_last_alter DESC
        LIMIT 300
        """
        df = self._executor.execute(query)
        logger.info("[SparkJobOptimizer] Delta issue findings: %d", len(df))
        return df

    # ──────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────

    def _safe_detect(self, name: str, fn: Callable) -> pd.DataFrame:
        """
        Wraps a detection method.  On exception, logs the error and returns
        an empty DataFrame so one failing detector doesn't abort the scan.
        """
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "[SparkJobOptimizer] Detection '%s' failed: %s", name, exc
            )
            return pd.DataFrame()

    # ──────────────────────────────────────────────────────────────
    # Serialisation helpers  (match other scanner conventions)
    # ──────────────────────────────────────────────────────────────

    @staticmethod
    def to_dict(result: ScanResult) -> Dict:
        """
        Convert a ScanResult to a plain dict for JSON/CSV export.
        Mirrors the dict structure returned by all other scanners
        (e.g. JobScanner, UnityCatalogScanner).
        """
        def _df_to_records(df: pd.DataFrame) -> List[Dict]:
            if df is None or df.empty:
                return []
            return [
                {k: (None if pd.isna(v) else v) for k, v in row.items()}
                for row in df.to_dict(orient="records")
            ]

        return {
            "summary": {
                "workspace_id"    : result.workspace_id,
                "workspace_name"  : result.workspace_name,
                "scan_timestamp"  : str(result.scan_timestamp),
                "scan_mode"       : result.scan_mode,
                "lookback_days"   : result.lookback_days,
                "total_findings"  : result.total_findings,
                "findings_by_category": {
                    "data_skew"           : len(result.skewed_jobs),
                    "shuffle_spill"       : len(result.shuffle_spill_jobs),
                    "small_files"         : len(result.small_file_jobs),
                    "broadcast_candidates": len(result.broadcast_candidates),
                    "long_running_jobs"   : len(result.long_running_jobs),
                    "failed_tasks"        : len(result.failed_tasks),
                    "delta_issues"        : len(result.delta_issues),
                },
            },
            "skewed_jobs"          : _df_to_records(result.skewed_jobs),
            "shuffle_spill_jobs"   : _df_to_records(result.shuffle_spill_jobs),
            "small_file_jobs"      : _df_to_records(result.small_file_jobs),
            "broadcast_candidates" : _df_to_records(result.broadcast_candidates),
            "long_running_jobs"    : _df_to_records(result.long_running_jobs),
            "failed_tasks"         : _df_to_records(result.failed_tasks),
            "delta_issues"         : _df_to_records(result.delta_issues),
        }

    @staticmethod
    def flatten_for_csv(scan_data: Dict) -> List[Dict]:
        """
        Flatten all finding categories into a single list of dicts for CSV export.
        Each row gets a 'category' column to distinguish finding types — the same
        approach used by UnityCatalogScanner.flatten_for_csv().
        """
        rows: List[Dict] = []
        summary = scan_data.get("summary", {})
        base = {
            "workspace_id"  : summary.get("workspace_id"),
            "workspace_name": summary.get("workspace_name"),
            "scan_timestamp": summary.get("scan_timestamp"),
            "lookback_days" : summary.get("lookback_days"),
        }
        category_keys = [
            ("skewed_jobs",          "data_skew"),
            ("shuffle_spill_jobs",   "shuffle_spill"),
            ("small_file_jobs",      "small_files"),
            ("broadcast_candidates", "broadcast_candidates"),
            ("long_running_jobs",    "long_running_jobs"),
            ("failed_tasks",         "failed_tasks"),
            ("delta_issues",         "delta_issues"),
        ]
        for key, category in category_keys:
            for record in scan_data.get(key, []):
                rows.append({**base, "category": category, **record})
        return rows

    def _get_warehouse_id(self) -> str:
        """
        Returns the SQL warehouse ID to use for query execution.

        Priority:
        1. ``spark_job_optimizer.warehouse_id`` from config
        2. First RUNNING warehouse discovered via SDK
        3. First warehouse of any state
        """
        wid = self._plugin_cfg.get("warehouse_id", "")
        if wid:
            return wid

        try:
            warehouses = list(self.client.warehouses.list())
            # Prefer a running warehouse
            for wh in warehouses:
                state_val = getattr(wh.state, "value", str(wh.state)) if wh.state else ""
                if state_val.upper() == "RUNNING":
                    logger.info(
                        "[SparkJobOptimizer] Auto-selected running warehouse: %s (%s)",
                        wh.id, wh.name,
                    )
                    return wh.id
            if warehouses:
                logger.info(
                    "[SparkJobOptimizer] Auto-selected first available warehouse: %s (%s)",
                    warehouses[0].id, warehouses[0].name,
                )
                return warehouses[0].id
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[SparkJobOptimizer] Could not auto-discover SQL warehouse: %s", exc
            )

        raise RuntimeError(
            "SparkJobOptimizerScanner requires a SQL Warehouse. "
            "Set 'spark_job_optimizer.warehouse_id' in config.json or ensure "
            "a running SQL Warehouse exists in the workspace."
        )

    def _get_workspace_id(self) -> str:
        """Returns the workspace ID string from the SDK client."""
        try:
            return str(self.client.get_workspace_id())
        except Exception:
            return "unknown"

    def _get_workspace_name(self) -> str:
        """Returns the workspace host URL as the workspace name."""
        try:
            return self.client.config.host or "unknown"
        except Exception:
            return "unknown"
