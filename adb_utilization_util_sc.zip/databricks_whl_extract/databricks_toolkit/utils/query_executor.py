"""
QueryExecutor — Class 7 (Plugin 1 + Plugin 2 shared utility).

Executes SQL statements against a Databricks SQL Warehouse via the
Databricks SDK ``StatementExecutionAPI``.  Always returns a
``pd.DataFrame``; an empty DataFrame is returned on error rather than
propagating exceptions to callers.

Features
--------
- Automatic retry (3x) with exponential backoff.
- Configurable execution timeout passed directly to the warehouse.
- Structured logging of query durations and failures.
- Converts SDK result chunks to a pandas DataFrame transparently.
"""

import logging
import time
from typing import Optional

import pandas as pd
from databricks.sdk import WorkspaceClient


logger = logging.getLogger(__name__)


class QueryExecutor:
    """
    Reusable SQL execution utility shared across Tier-3 scanner plugins.

    Parameters
    ----------
    client        : Authenticated ``databricks.sdk.WorkspaceClient``.
    warehouse_id  : ID of the SQL Warehouse used for statement execution.
    timeout_secs  : Maximum seconds to wait for a query result (default 50, max 50).
    """

    MAX_RETRIES   : int = 3
    POLL_INTERVAL : int = 2   # seconds between status polls

    # Databricks Statement Execution API only accepts wait_timeout of
    # 0s (async/poll) OR between 5s and 50s (synchronous wait).
    # Any value outside that range raises a validation error.
    _MIN_WAIT_SECS : int = 5
    _MAX_WAIT_SECS : int = 50

    def __init__(
        self,
        client       : WorkspaceClient,
        warehouse_id : str,
        timeout_secs : int = 50,
    ):
        self.client       = client
        self.warehouse_id = warehouse_id
        self.timeout_secs = timeout_secs

    # ──────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────

    def execute(self, query: str) -> pd.DataFrame:
        """
        Execute a SQL query and return results as a pandas DataFrame.

        Retries up to ``MAX_RETRIES`` times with exponential backoff.
        Returns an empty DataFrame if all attempts fail.

        Parameters
        ----------
        query : SQL statement to execute.

        Returns
        -------
        pd.DataFrame — query results, or empty DataFrame on failure.
        """
        for attempt in range(self.MAX_RETRIES):
            try:
                logger.debug(
                    "QueryExecutor: executing (attempt %d/%d)",
                    attempt + 1,
                    self.MAX_RETRIES,
                )
                t0 = time.time()
                # Clamp wait_timeout to the API-accepted range:
                # 0s = async (SDK polls for result), or 5s–50s (sync wait).
                if self.timeout_secs == 0:
                    _wait_str = "0s"
                else:
                    _clamped = min(self._MAX_WAIT_SECS, max(self._MIN_WAIT_SECS, self.timeout_secs))
                    _wait_str = f"{_clamped}s"
                response = self.client.statement_execution.execute_statement(
                    warehouse_id=self.warehouse_id,
                    statement=query,
                    wait_timeout=_wait_str,
                )
                elapsed = round(time.time() - t0, 2)
                logger.info("QueryExecutor: completed in %ss", elapsed)
                return self._to_dataframe(response)

            except Exception as exc:  # noqa: BLE001
                if attempt == self.MAX_RETRIES - 1:
                    self._handle_error(exc, query)
                wait = 2 ** attempt
                logger.warning(
                    "QueryExecutor: attempt %d failed (%s) — retrying in %ds",
                    attempt + 1,
                    exc,
                    wait,
                )
                time.sleep(wait)

        return pd.DataFrame()

    # ──────────────────────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────────────────────

    def _to_dataframe(self, result) -> pd.DataFrame:
        """
        Convert a ``StatementResponse`` SDK object to a pandas DataFrame.

        Returns an empty DataFrame when the response contains no result data.
        """
        if result is None:
            return pd.DataFrame()

        manifest = getattr(result, "manifest", None)
        if manifest is None:
            return pd.DataFrame()

        schema = getattr(manifest, "schema", None)
        if schema is None or not getattr(schema, "columns", None):
            return pd.DataFrame()

        columns = [c.name for c in schema.columns]

        result_obj = getattr(result, "result", None)
        data_array = getattr(result_obj, "data_array", None) if result_obj else None

        if not data_array:
            # Query succeeded but returned zero rows
            return pd.DataFrame(columns=columns)

        rows = []
        for row in data_array:
            values = getattr(row, "values", None)
            if values is None:
                # data_array may already be a list-of-lists
                rows.append(row)
            else:
                rows.append([getattr(v, "str", v) for v in values])

        return pd.DataFrame(rows, columns=columns)

    def _handle_error(self, error: Exception, query: str) -> None:
        """
        Log a structured error message and raise RuntimeError.

        Raises
        ------
        RuntimeError — always raised after logging.
        """
        logger.error(
            "QueryExecutor: query failed after %d attempts.\n"
            "Error : %s\n"
            "Query : %s",
            self.MAX_RETRIES,
            error,
            query[:300],
        )
        raise RuntimeError(f"QueryExecutor failed: {error}") from error
