"""
Data models for Databricks Toolkit plugins.
"""

from .spark_optimizer_models import (
    OptimizationFinding,
    OptimizationRecommendation,
    ScanResult,
)

__all__ = [
    "OptimizationFinding",
    "OptimizationRecommendation",
    "ScanResult",
]
