# Databricks notebook source
# MAGIC %md
# MAGIC # Databricks Workspace Discovery Scanner
# MAGIC
# MAGIC This notebook performs an automated discovery of Databricks workspace assets, configurations, and usage patterns.  
# MAGIC It is designed to help administrators gain visibility into workspace structure, Cluster Information, Job Details, Pipelines, unity catalog, security information, utilization metrics , and operational artifacts.
# MAGIC
# MAGIC
# MAGIC ### Key Outcomes
# MAGIC - Workspace-wide inventory of compute, jobs, pipelines, and governance objects
# MAGIC - Utilization and cost-related signals to support optimization discussions
# MAGIC - Structured outputs for cataloging of Databricks Assets in a workspace

# COMMAND ----------

# MAGIC %md
# MAGIC ## Environment Setup and Toolkit Installation
# MAGIC
# MAGIC This cell installs and initializes the required Databricks Toolkit components used for workspace discovery.
# MAGIC It ensures that all supporting libraries and dependencies are consistently available before execution begins.
# MAGIC
# MAGIC **Why this matters**
# MAGIC - Guarantees version-aligned tooling
# MAGIC - Avoids dependency conflicts during scan execution
# MAGIC - Enables repeatable execution across workspaces and environments
# MAGIC

# COMMAND ----------

# Replace the path with your wheel file location
%pip install --force-reinstall --no-deps --no-cache-dir /Volumes/ext_nyc_cat_ci/etlschema/etlvolume/script/databricks_toolkit-2.0.10-py3-none-any.whl

# COMMAND ----------

# MAGIC %pip install databricks-sdk --upgrade

# COMMAND ----------

# Restart Python to load the newly installed package
dbutils.library.restartPython()

# COMMAND ----------

import pkg_resources
print(pkg_resources.get_distribution("databricks-sdk").version)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scan Configuration
# MAGIC
# MAGIC This section defines all configurable parameters that control the discovery scan behavior.
# MAGIC
# MAGIC ### Key Settings
# MAGIC - **Workspace URL** – Target Databricks workspace
# MAGIC - **Scan Type** – Simple or Deep (controls metadata vs. utilization depth)
# MAGIC - **Unity Catalog Mode** – Partial or Complete hierarchy scan
# MAGIC - **Billing & Utilization Windows** – Defines historical analysis range
# MAGIC - **Parallelism Controls** – Worker concurrency to balance performance and load
# MAGIC
# MAGIC These parameters should be reviewed and customized per environment before running the scan.

# COMMAND ----------

# -------------------------------------------------------------------
# Spark Job Optimizer — Delta Write Widget
# Run this cell first, then set the dropdown at the top of the
# notebook before executing the scan.  Matching the confirm_insert
# pattern used in 02_generate_all_analysis.
# -------------------------------------------------------------------
dbutils.widgets.removeAll()
dbutils.widgets.dropdown(
    name         = "write_to_delta",
    defaultValue = "N",
    choices      = ["N", "Y"],
    label        = "Write Spark Optimizer results to Delta Tables?"
)

dbutils.widgets.text(
    name         = "WORKSPACE_URL",
    defaultValue = "",
    label        = "Workspace URL"
)
dbutils.widgets.text(
    name         = "ACCOUNT_ID",
    defaultValue = "",
    label        = "Account ID (optional - for account-level security scans)"
)
dbutils.widgets.text(
    name         = "DISCOVERY_OUTPUT",
    defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/out/discovery/",
    label        = "Output Directory"
)

dbutils.widgets.dropdown(
    name         = "SCAN_TYPE",
    defaultValue = "deep",
    choices      = ["simple", "deep"],
    label        = "Scan Type"
)
dbutils.widgets.dropdown(
    name         = "UC_SCAN",
    defaultValue = "partial",
    choices      = ["partial", "complete"],
    label        = "UC Scan Mode"
)
dbutils.widgets.dropdown(
    name         = "BILLING_ENABLED",
    defaultValue = "Y",
    choices      = ["Y", "N"],
    label        = "Enable Billing Data"
)
dbutils.widgets.text(
    name         = "BILLING_DAYS",
    defaultValue = "30",
    label        = "Billing Days (1-30)"
)
dbutils.widgets.text(
    name         = "UTILIZATION_DAYS",
    defaultValue = "180",
    label        = "Utilization Days"
)
dbutils.widgets.dropdown(
    name         = "EXPORT_FORMAT",
    defaultValue = "json",
    choices      = ["json", "csv"],
    label        = "Export Format"
)
dbutils.widgets.text(
    name         = "MAX_WORKERS",
    defaultValue = "6",
    label        = "Max parallel workers"
)
# print("Widget created above ↑  —  set to 'Y' to persist findings to Delta tables.")

# COMMAND ----------

from databricks_toolkit.discovery import ScanConfig, WorkspaceDiscoveryScanner

# ===================================================================
# CONFIGURATION - Update these values for your environment
# ===================================================================

# Get workspace URL from widget
WORKSPACE_URL = dbutils.widgets.get("WORKSPACE_URL")

# Output directory where discovery data will be saved
DISCOVERY_OUTPUT = dbutils.widgets.get("DISCOVERY_OUTPUT")

# Scan configuration from widgets
SCAN_TYPE = dbutils.widgets.get("SCAN_TYPE")                            # 'simple' or 'deep' (deep collects utilization metrics)
UC_SCAN = dbutils.widgets.get("UC_SCAN")                                # 'partial' (faster, tables only) or 'complete' (full hierarchy)
BILLING_ENABLED = dbutils.widgets.get("BILLING_ENABLED")               # 'Y' to collect billing data, 'N' to skip

# Convert string widget values to integers (widgets always return strings)
BILLING_DAYS = int(dbutils.widgets.get("BILLING_DAYS"))                # Number of days of billing data to collect (1-365)
UTILIZATION_DAYS = int(dbutils.widgets.get("UTILIZATION_DAYS"))        # Number of days of utilization metrics (for deep scan)
MAX_WORKERS = int(dbutils.widgets.get("MAX_WORKERS"))                  # Parallel threads (1-10, higher = faster but more load)

# Other settings
EXPORT_FORMAT = dbutils.widgets.get("EXPORT_FORMAT")                    # 'json' or 'csv'

# Optional: Account ID for account-level security scanning
ACCOUNT_ID = dbutils.widgets.get("ACCOUNT_ID").strip() or None          # Empty string becomes None

# -------------------------------------------------------------------
# Plugin 1 — Spark Job Optimizer  (requires scan_type = 'deep')
# Set 'enabled' to True to activate. All other keys are optional.
# -------------------------------------------------------------------
SPARK_JOB_OPTIMIZER_CONFIG = {
    "enabled": True,                # Set True to run the plugin
    "warehouse_id": "",              # SQL warehouse for system-table queries (auto-detected if blank)
    "lookback_days": 7,              # History window in days
    "skew_threshold": 10.0,          # Data-skew ratio that triggers a finding
    "spill_threshold_mb": 500.0,     # Shuffle-spill MB that triggers a finding
    "small_files_threshold": 1000,   # File count that triggers a small-files finding
    "output_dir": DISCOVERY_OUTPUT + "spark_optimizer/",  # Where to write the Excel report
    "write_to_delta": dbutils.widgets.get("write_to_delta"),  # set via widget above
    "delta_catalog": "dbscannercatalog",
    "delta_schema":  "catalog_inventory",
}

print("✓ Configuration loaded")
print(f"  Workspace: {WORKSPACE_URL}")
print(f"  Output: {DISCOVERY_OUTPUT}")
print(f"  Scan Type: {SCAN_TYPE}")
print(f"  UC Scan Mode: {UC_SCAN}")
print(f"  Spark Job Optimizer: {'Enabled' if SPARK_JOB_OPTIMIZER_CONFIG['enabled'] else 'Disabled'}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Run Discovery Scan
# MAGIC This initializes the workspace discovery scanner using the provided configuration and save results to the specified output directory.

# COMMAND ----------

# Create scan configuration
config = ScanConfig(
    scan_type=SCAN_TYPE,
    workspace_urls=[WORKSPACE_URL],
    uc_scan=UC_SCAN,
    billing_details=BILLING_ENABLED,
    billing_days=BILLING_DAYS,              # Now properly typed as int
    utilization_days=UTILIZATION_DAYS,      # Now properly typed as int
    export_format=EXPORT_FORMAT,
    max_workers=MAX_WORKERS,                # Now properly typed as int
    output_file=DISCOVERY_OUTPUT,
    account_id=ACCOUNT_ID,                  # Optional, from widget (None if not provided)
    log_level='INFO',
    spark_job_optimizer=SPARK_JOB_OPTIMIZER_CONFIG
)

print("="*80)
print("STARTING WORKSPACE DISCOVERY SCAN")
print("="*80)
print(f"\nScan Configuration:")
print(f"  • Scan Type: {config.scan_type.upper()}")
print(f"  • UC Scan: {config.uc_scan.upper()}")
print(f"  • Billing: {'Enabled' if config.is_billing_enabled() else 'Disabled'} ({config.billing_days} days)")
print(f"  • Utilization: {config.utilization_days} days")
print(f"  • Workers: {config.max_workers}")
print(f"  • Format: {config.export_format.upper()}")
print(f"\n" + "="*80 + "\n")

# Initialize scanner and run
scanner = WorkspaceDiscoveryScanner(config)
results = scanner.scan_workspaces()

print(f"\n" + "="*80)
print("✓ DISCOVERY SCAN COMPLETE")
print("="*80)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scan Results Summary Catalog Dashboards
# MAGIC
# MAGIC This section summarizes the overall completion of the discovery scan.
# MAGIC It reports execution duration, scan tier performance, and artifact coverage.
# MAGIC
# MAGIC ✅ Successful completion indicates:
# MAGIC - All configured scan tiers executed
# MAGIC - Results available for analysis and populated in Dashboard
# MAGIC - Output artifacts written to storage

# COMMAND ----------

# DBTITLE 1,Cell 10
from pyspark.sql import Row
from pyspark.sql.functions import to_timestamp, col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, BooleanType, TimestampType

import uuid

# Helper to extract artifact counts safely
def get_count(artifacts, key, default=0):
    val = artifacts.get(key, {})
    if isinstance(val, dict):
        return int(val.get('total_count', default))
    elif isinstance(val, list):
        return int(len(val))
    return int(default)

# Helper to safely get nested dict values
def get_nested(artifacts, key, subkey, default=0):
    val = artifacts.get(key, {})
    if isinstance(val, dict):
        subval = val.get(subkey, default)
        # Handle case where subval might be a list
        if isinstance(subval, list):
            return int(len(subval))
        return int(subval)
    return int(default)

# Prepare rows for DataFrame
cur_scan_id=str(uuid.uuid4())
rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    row = Row(
        scan_id=cur_scan_id,
        workspace_id=ws.get('workspace_id', ''),
        workspace_url=ws.get('workspace_url', ''),
        scan_start_timestamp=results['scan_metadata'].get('start_time', ''),
        scan_end_timestamp=results['scan_metadata'].get('end_time', ''),
        scan_duration_seconds=float(results['scan_metadata'].get('total_duration_seconds', 0.0)),
        scan_type=results['scan_metadata'].get('scan_type', ''),
        total_clusters=get_count(artifacts, 'clusters'),
        total_jobs=get_count(artifacts, 'jobs'),
        total_pipelines=get_count(artifacts, 'pipelines'),
        total_uc_tables=int(artifacts.get('unity_catalog', {}).get('summary', {}).get('total_tables', 0)),
        total_warehouses=get_count(artifacts, 'warehouses'),
        total_ml_experiments=get_nested(artifacts, 'workspace_objects', 'experiments'),
        total_repos=get_nested(artifacts, 'workspace_objects', 'repos'),
        total_serving_endpoints=get_nested(artifacts, 'workspace_objects', 'serving_endpoints'),
        total_genie_spaces=get_nested(artifacts, 'workspace_objects', 'genie_spaces'),
        total_alerts=get_count(artifacts, 'alerts'),
        total_notebooks=get_nested(artifacts, 'workspace_objects', 'notebooks')
    )
    rows.append(row)

df = spark.createDataFrame(rows)

# Convert scan_timestamp string to timestamp type
df = df.withColumn('scan_start_timestamp', to_timestamp('scan_start_timestamp'))
df = df.withColumn('scan_end_timestamp', to_timestamp('scan_end_timestamp'))

# Cast all integer columns to int type to match table schema
int_columns = [
    'total_clusters', 'total_jobs', 'total_pipelines', 'total_uc_tables', 'total_warehouses',
    'total_ml_experiments', 'total_repos','total_serving_endpoints', 'total_genie_spaces', 'total_alerts', 'total_notebooks'
]

for col_name in int_columns:
    df = df.withColumn(col_name, col(col_name).cast('int'))

df.write.mode("append").saveAsTable("dbscannercatalog.catalog_inventory.workspace_scan_summary")

cluster_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    clusters = artifacts.get('clusters', {}).get('items', []) if isinstance(artifacts.get('clusters', {}), dict) else artifacts.get('clusters', [])
    for c in clusters:
        cluster_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            #scan_start_timestamp=results['scan_metadata'].get('start_time', ''),
            #scan_end_timestamp=results['scan_metadata'].get('end_time', ''),
            cluster_id=c.get('cluster_id', ''),
            cluster_name=c.get('cluster_name', ''),
            state=c.get('state', ''),
            cluster_source=c.get('cluster_source', ''),
            node_type_id=c.get('node_type_id', ''),
            driver_node_type_id=c.get('driver_node_type_id', ''),
            min_workers=c.get('min_workers'),
            max_workers=c.get('max_workers'),
            num_workers=c.get('num_workers'),
            autotermination_minutes=c.get('autotermination_minutes'),
            creator_user_name=c.get('creator_user_name', ''),
            #start_time=c.get('start_time', ''),
            uptime_hours=c.get('uptime_hours'),
            spot_enabled=c.get('spot', c.get('spot_enabled', None)),
            enable_elastic_disk=c.get('enable_elastic_disk'),
            spark_version=c.get('spark_version', ''),
            policy_id=c.get('policy_id', '')
        ))

cluster_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    #StructField("scan_start_timestamp", TimestampType(), False),
    #StructField("scan_end_timestamp", TimestampType(), False),
    StructField("cluster_id", StringType(), False),
    StructField("cluster_name", StringType(), True),
    StructField("state", StringType(), True),
    StructField("cluster_source", StringType(), True),
    StructField("node_type_id", StringType(), True),
    StructField("driver_node_type_id", StringType(), True),
    StructField("min_workers", IntegerType(), True),
    StructField("max_workers", IntegerType(), True),
    StructField("num_workers", IntegerType(), True),
    StructField("autotermination_minutes", IntegerType(), True),
    StructField("creator_user_name", StringType(), True),
    #StructField("start_time", TimestampType(), True),
    StructField("uptime_hours", DoubleType(), True),
    StructField("spot_enabled", BooleanType(), True),
    StructField("enable_elastic_disk", BooleanType(), True),
    StructField("spark_version", StringType(), True),
    StructField("policy_id", StringType(), True)
])

cluster_df = spark.createDataFrame(cluster_rows, schema=cluster_schema)
#cluster_df = cluster_df.withColumn('scan_start_timestamp', to_timestamp('scan_start_timestamp'))
#cluster_df = cluster_df.withColumn('scan_end_timestamp', to_timestamp('scan_end_timestamp'))
#cluster_df = cluster_df.withColumn('start_time', to_timestamp('start_time'))

cluster_df.write.mode("append").saveAsTable("dbscannercatalog.catalog_inventory.workspace_scan_clusters")

uc_table_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    uc = artifacts.get('unity_catalog', {})
    tables = []
    # Try summary->tables, else fallback to tables key
    if isinstance(uc, dict):
        if 'tables' in uc:
            tables = uc['tables']
        elif 'summary' in uc and 'tables' in uc['summary']:
            tables = uc['summary']['tables']
    for t in tables:
        uc_table_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            catalog_name=t.get('catalog_name', ''),
            schema_name=t.get('schema_name', ''),
            table_name=t.get('table_name', ''),
            table_type=t.get('table_type', ''),
            table_format=t.get('data_source_format') if t.get('data_source_format') is not None else '',
            storage_location=t.get('metastore_path') if t.get('data_source_format') is not None else '',
            is_delta=bool(t.get('is_delta', False))
        ))

uc_table_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("catalog_name", StringType(), True),
    StructField("schema_name", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("table_type", StringType(), True),
    StructField("table_format", StringType(), True),
    StructField("storage_location", StringType(), True),
    StructField("is_delta", BooleanType(), True)
])

workspace_scan_uc_tables_df = spark.createDataFrame(uc_table_rows, schema=uc_table_schema)
workspace_scan_uc_tables_df.write.mode("append").saveAsTable("dbscannercatalog.catalog_inventory.workspace_scan_uc_tables")

warehouse_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    warehouses = artifacts.get('warehouses', {}).get('items', []) if isinstance(artifacts.get('warehouses', {}), dict) else artifacts.get('warehouses', [])
    for w in warehouses:
        warehouse_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            warehouse_id=w.get('warehouse_id', ''),
            warehouse_name=w.get('warehouse_name', ''),
            cluster_size=w.get('cluster_size', ''),
            min_num_clusters=w.get('min_num_clusters'),
            max_num_clusters=w.get('max_num_clusters'),
            auto_stop_mins=w.get('auto_stop_mins'),
            state=w.get('state', ''),
            warehouse_type=w.get('warehouse_type', ''),
            enable_photon=w.get('enable_photon'),
            enable_serverless_compute=w.get('enable_serverless_compute'),
            spot_instance_policy=w.get('spot_instance_policy', ''),
            creator_name=w.get('creator_name', '')
        ))

warehouse_schema = StructType([
    StructField("workspace_id", StringType(), True),
    StructField("scan_id", StringType(), False),
    StructField("warehouse_id", StringType(), False),
    StructField("warehouse_name", StringType(), True),
    StructField("cluster_size", StringType(), True),
    StructField("min_num_clusters", IntegerType(), True),
    StructField("max_num_clusters", IntegerType(), True),
    StructField("auto_stop_mins", IntegerType(), True),
    StructField("state", StringType(), True),
    StructField("warehouse_type", StringType(), True),
    StructField("enable_photon", BooleanType(), True),
    StructField("enable_serverless_compute", BooleanType(), True),
    StructField("spot_instance_policy", StringType(), True),
    StructField("creator_name", StringType(), True)
])

warehouse_df = spark.createDataFrame(warehouse_rows, schema=warehouse_schema)
warehouse_df.write.mode("append").saveAsTable("dbscannercatalog.catalog_inventory.workspace_scan_warehouses")

pipeline_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    pipelines = artifacts.get('pipelines', {}).get('items', []) if isinstance(artifacts.get('pipelines', {}), dict) else artifacts.get('pipelines', [])
    for p in pipelines:
        pipeline_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            pipeline_id=p.get('pipeline_id', ''),
            pipeline_name=p.get('name', ''),
            state=p.get('state', ''),
            creator_user_name=p.get('creator_user_name', ''),
            creation_time=p.get('creation_time', None)
        ))

pipeline_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("pipeline_id", StringType(), False),
    StructField("pipeline_name", StringType(), True),
    StructField("state", StringType(), True),
    StructField("creator_user_name", StringType(), True),
    StructField("creation_time", TimestampType(), True)
])

pipeline_df = spark.createDataFrame(pipeline_rows, schema=pipeline_schema)
pipeline_df = pipeline_df.withColumn("creation_time", to_timestamp("creation_time"))
pipeline_df.write.mode("append").saveAsTable("dbscannercatalog.catalog_inventory.workspace_scan_pipelines")
