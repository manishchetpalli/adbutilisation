# Databricks notebook source
# dbutils.widgets.removeAll()   # reset any leftover widgets from previous runs
dbutils.widgets.dropdown(
    name    = "confirm_insert",
    defaultValue = "No",
    choices = ["No", "Yes"],
    label   = "Save analysis to Delta Tables?"
)
dbutils.widgets.text(
    name         = "RULES_PATH",
    defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/script/analyzer_rules.json",
    label        = "Rule File"
)
# dbutils.widgets.text(
#     name         = "DISCOVERY_OUTPUT",
#     defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/script/analyzer_rules.json",
#     label        = "DISCOVERY OUTPUT"
# )
dbutils.widgets.text(
    name         = "DISCOVERY_OUTPUT",
    defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/out/discovery",
    label        = "DISCOVERY OUTPUT"
)
dbutils.widgets.text(
    name         = "ANALYSIS_OUTPUT",
    defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/out/analysis",
    label        = "ANALYSIS OUTPUT"
)
dbutils.widgets.text(
    name         = "_CATALOG",
    defaultValue = "ext_nyc_cat_ci",
    label        = "ANALYSIS Result Catalog"
)
dbutils.widgets.text(
    name         = "_SCHEMA",
    defaultValue = "catalog_inventory",
    label        = "ANALYSIS Result Schema"
)

# COMMAND ----------

# Install required packages
# --no-deps: pandas and numpy are already provided by Databricks Runtime - do not reinstall them
%pip install --force-reinstall --no-deps --no-cache-dir /Volumes/ext_nyc_cat_ci/etlschema/etlvolume/script/databricks_toolkit-2.0.10-py3-none-any.whl
# openpyxl is NOT bundled in Databricks Runtime - must be installed explicitly
%pip install openpyxl --quiet


# COMMAND ----------

# Restart Python to load the newly installed package
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration
# MAGIC
# MAGIC **IMPORTANT:** Update the paths below to match your environment.

# COMMAND ----------

import os
import shutil
from datetime import datetime

# Import analysis components
from databricks_toolkit.analysis import (
    ClusterUtilizationAnalyzer,
    QueryUtilizationAnalyzer,
    SecurityAnalyzer,
    SparkJobOptimizerAnalyzer,
    SparkRecommendationEngine,
    run_consolidated_cluster_analysis
)
from databricks_toolkit.models.spark_optimizer_models import ScanResult as SparkScanResult

# ===================================================================
# CONFIGURATION - Update these paths
# ===================================================================
RULES_PATH      = dbutils.widgets.get("RULES_PATH")
# Discovery output path (from discovery notebook)
DISCOVERY_OUTPUT = dbutils.widgets.get("DISCOVERY_OUTPUT")

# Analysis output directory (where Excel reports will be saved)
ANALYSIS_OUTPUT = dbutils.widgets.get("ANALYSIS_OUTPUT")

# Local temporary directory for analysis processing
# Use a unique timestamp-based directory to avoid permission conflicts
import time
timestamp = int(time.time())
ANALYSIS_TEMP_DIR = f"/tmp/workspace_analysis_{timestamp}"

print("✓ Configuration loaded")
print(f"  Discovery Input: {DISCOVERY_OUTPUT}")
print(f"  Rules File Path: {RULES_PATH}")
print(f"  Analysis Output: {ANALYSIS_OUTPUT}")
print(f"  Temp Directory: {ANALYSIS_TEMP_DIR}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Detect Data Paths
# MAGIC
# MAGIC Automatically find cluster, query, jobs, and security data.

# COMMAND ----------

def find_data_paths(discovery_root):
    """
    Find all data paths from discovery output.
    Handles both workspace-specific folders (ws_*) and direct structure.
    Each analyzer knows which subdirectory to look in under the workspace folder.
    """
    paths = {
        'cluster_input': None,
        'query_input': None,
        'jobs_input': None,
        'security_input': None,
        'spark_optimizer_input': None,
    }
    
    try:
        # Convert path to local for os operations
        local_discovery_root = discovery_root.replace('/dbfs/', '/').replace('dbfs:', '')
        if not local_discovery_root.startswith('/') and not local_discovery_root.startswith('/Volumes/'):
            local_discovery_root = '/dbfs' + local_discovery_root
            
        if os.path.exists(local_discovery_root):
            workspace_folders = [d for d in os.listdir(local_discovery_root) 
                               if os.path.isdir(os.path.join(local_discovery_root, d)) and d.startswith('ws_')]
            
            if workspace_folders:
                # Workspace folder structure
                workspace_folder = os.path.join(local_discovery_root, workspace_folders[0])
                paths['cluster_input'] = os.path.join(workspace_folder, 'utilization', 'cluster')
                paths['query_input'] = os.path.join(workspace_folder, 'utilization', 'query')
                paths['jobs_input'] = os.path.join(workspace_folder, 'jobs', 'json')
                
                # Check for security data (json preferred, csv fallback)
                for folder_type in ['json', 'csv']:
                    security_path = os.path.join(workspace_folder, 'security', folder_type)
                    if os.path.exists(security_path):
                        security_files = [f for f in os.listdir(security_path) 
                                        if f.endswith(('.json', '.csv'))]
                        if security_files:
                            paths['security_input'] = os.path.join(security_path, security_files[0])
                            break

                # Check for spark job optimizer data (json preferred, csv fallback)
                for folder_type in ['json', 'csv']:
                    sjo_path = os.path.join(workspace_folder, 'spark_job_optimizer', folder_type)
                    if os.path.exists(sjo_path):
                        sjo_files = sorted([f for f in os.listdir(sjo_path)
                                            if f.endswith(('.json', '.csv'))])
                        if sjo_files:
                            paths['spark_optimizer_input'] = os.path.join(sjo_path, sjo_files[-1])
                            break
            else:
                # Direct structure
                paths['cluster_input'] = os.path.join(local_discovery_root, 'utilization', 'cluster')
                paths['query_input'] = os.path.join(local_discovery_root, 'utilization', 'query')
                paths['jobs_input'] = os.path.join(local_discovery_root, 'jobs', 'json')
                
                # Check for security data
                for folder_type in ['json', 'csv']:
                    security_path = os.path.join(local_discovery_root, 'security', folder_type)
                    if os.path.exists(security_path):
                        security_files = [f for f in os.listdir(security_path) 
                                        if f.endswith(('.json', '.csv'))]
                        if security_files:
                            paths['security_input'] = os.path.join(security_path, security_files[0])
                            break

                # Check for spark job optimizer data
                for folder_type in ['json', 'csv']:
                    sjo_path = os.path.join(local_discovery_root, 'spark_job_optimizer', folder_type)
                    if os.path.exists(sjo_path):
                        sjo_files = sorted([f for f in os.listdir(sjo_path)
                                            if f.endswith(('.json', '.csv'))])
                        if sjo_files:
                            paths['spark_optimizer_input'] = os.path.join(sjo_path, sjo_files[-1])
                            break
    except Exception as e:
        print(f"Error determining paths: {e}")
    
    return paths

# Find data paths
data_paths = find_data_paths(DISCOVERY_OUTPUT)

print("\nData paths identified:")
print(f"  📊 Cluster: {data_paths['cluster_input']}")
print(f"     Exists: {os.path.exists(data_paths['cluster_input']) if data_paths['cluster_input'] else False}")

print(f"  📊 Query: {data_paths['query_input']}")
print(f"     Exists: {os.path.exists(data_paths['query_input']) if data_paths['query_input'] else False}")

print(f"  📊 Jobs: {data_paths['jobs_input']}")
print(f"     Exists: {os.path.exists(data_paths['jobs_input']) if data_paths['jobs_input'] else False}")

print(f"  📊 Security: {data_paths['security_input']}")
print(f"     Exists: {os.path.exists(data_paths['security_input']) if data_paths['security_input'] else False}")

print(f"  📊 Spark Job Optimizer: {data_paths['spark_optimizer_input']}")
print(f"     Exists: {os.path.exists(data_paths['spark_optimizer_input']) if data_paths['spark_optimizer_input'] else False}")

# Verify at least cluster data exists
if not data_paths['cluster_input'] or not os.path.exists(data_paths['cluster_input']):
    print("\n❌ ERROR: Cluster data not found!")
    print("   Please verify discovery notebook ran successfully with scan_type='deep'")
    dbutils.notebook.exit("Discovery data not found")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Run Complete Analysis
# MAGIC
# MAGIC This cell executes ALL analyzers and generates comprehensive reports:
# MAGIC 1. **Cluster Analysis** - 7 consolidated analyzers (utilization, network, RI, worker nodes, single-node, autoscaling, recommendations)
# MAGIC 2. **Job Analysis** - Job configuration and execution patterns
# MAGIC 3. **Query Analysis** - SQL Warehouse query performance (if data available)
# MAGIC 4. **Security Analysis** - Comprehensive security posture assessment
# MAGIC 5. **Spark Job Optimizer Analysis** - Data skew, shuffle spill, small files, long-running jobs, failed tasks, Delta issues (if data available)
# MAGIC
# MAGIC All reports are saved as Excel files in the output directory.
# MAGIC

# COMMAND ----------

print("="*80)
print("RUNNING COMPREHENSIVE WORKSPACE ANALYSIS")
print("="*80)
print(f"\nThis will generate:")
print(f"  1. Cluster Analysis (7 analyzers consolidated)")
print(f"  2. Job Analysis")
print(f"  3. Query Analysis (if data available)")
print(f"  4. Security Analysis (if data available)")
print(f"  5. Spark Job Optimizer Analysis (if data available)")
print(f"\nOutput: {ANALYSIS_OUTPUT}")
print("="*80 + "\n")

# Create temporary directory with proper cleanup
temp_dir = os.path.join(ANALYSIS_TEMP_DIR, 'comprehensive')

# Clean up any existing temp directory first
if os.path.exists(ANALYSIS_TEMP_DIR):
    try:
        shutil.rmtree(ANALYSIS_TEMP_DIR)
        print(f"✓ Cleaned up existing temp directory")
    except Exception as e:
        print(f"⚠️  Warning: Could not clean existing temp dir: {e}")

# Create fresh temp directory
try:
    os.makedirs(temp_dir, mode=0o777, exist_ok=True)
    print(f"✓ Created temp directory: {temp_dir}")
except Exception as e:
    print(f"❌ Error creating temp directory: {e}")
    # Fallback to a simpler path
    temp_dir = f"/tmp/analysis_{timestamp}"
    os.makedirs(temp_dir, mode=0o777, exist_ok=True)
    print(f"✓ Using fallback temp directory: {temp_dir}")

# Determine output path based on storage type
if ANALYSIS_OUTPUT.startswith('/Volumes/'):
    output_path = ANALYSIS_OUTPUT
elif ANALYSIS_OUTPUT.startswith('/dbfs/') or ANALYSIS_OUTPUT.startswith('dbfs:/'):
    output_path = ANALYSIS_OUTPUT.replace('dbfs:/', '/dbfs/')
    if not output_path.startswith('/dbfs'):
        output_path = '/dbfs' + output_path
else:
    output_path = '/dbfs' + ANALYSIS_OUTPUT

os.makedirs(output_path, exist_ok=True)

reports_generated = []
sjo_scan_result   = None   # declared here so the preview and Delta cells can reference it
sjo_analyzer      = SparkJobOptimizerAnalyzer({})

try:
    # =========================================================================
    # 1. CLUSTER + JOB ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 1/5: RUNNING CLUSTER + JOB ANALYSIS")
    print(f"{'='*80}\n")
    
    cluster_results = run_consolidated_cluster_analysis(
        cluster_input_path=data_paths['cluster_input'],
        output_dir=temp_dir,
        job_input_path=data_paths['jobs_input'],
        rules_path=RULES_PATH
    )
    
    # Copy cluster report
    if cluster_results.get('cluster_output_file') and os.path.exists(cluster_results['cluster_output_file']):
        cluster_dst = os.path.join(output_path, os.path.basename(cluster_results['cluster_output_file']))
        shutil.copy2(cluster_results['cluster_output_file'], cluster_dst)
        reports_generated.append(f"Cluster Analysis: {os.path.basename(cluster_results['cluster_output_file'])}")
        print(f"\n✓ Cluster report saved: {os.path.basename(cluster_results['cluster_output_file'])}")
    
    # Copy job report
    if cluster_results.get('job_output_file') and os.path.exists(cluster_results['job_output_file']):
        job_dst = os.path.join(output_path, os.path.basename(cluster_results['job_output_file']))
        shutil.copy2(cluster_results['job_output_file'], job_dst)
        reports_generated.append(f"Job Analysis: {os.path.basename(cluster_results['job_output_file'])}")
        print(f"✓ Job report saved: {os.path.basename(cluster_results['job_output_file'])}")
    
    # =========================================================================
    # 2. QUERY ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 2/5: RUNNING QUERY ANALYSIS")
    print(f"{'='*80}\n")
    
    if data_paths['query_input'] and os.path.exists(data_paths['query_input']):
        try:
            query_analyzer = QueryUtilizationAnalyzer(
                input_path=data_paths['query_input'],
                output_dir=temp_dir
            )
            
            query_results = query_analyzer.analyze()
            
            # Copy query report
            if query_results.get('output_file') and os.path.exists(query_results['output_file']):
                query_dst = os.path.join(output_path, os.path.basename(query_results['output_file']))
                shutil.copy2(query_results['output_file'], query_dst)
                reports_generated.append(f"Query Analysis: {os.path.basename(query_results['output_file'])}")
                print(f"\n✓ Query report saved: {os.path.basename(query_results['output_file'])}")
        except FileNotFoundError as e:
            print(f"⚠️  Query data not found: {e}")
            print("   This is normal if no SQL Warehouses were active during discovery")
        except Exception as e:
            print(f"⚠️  Query analysis skipped: {e}")
    else:
        print("⚠️  Query data not found - skipping query analysis")
        print("   This is normal if no SQL Warehouses were active during discovery")
    
    # =========================================================================
    # 3. SECURITY ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 3/5: RUNNING SECURITY ANALYSIS")
    print(f"{'='*80}\n")
    
    if data_paths['security_input'] and os.path.exists(data_paths['security_input']):
        try:
            print(f"✓ Security data located: {data_paths['security_input']}")
            
            security_analyzer = SecurityAnalyzer(
                discovery_path=data_paths['security_input'],
                output_dir=temp_dir
            )
            
            security_results = security_analyzer.analyze()
            
            # Copy security report - handle different return structures
            output_file = None
            
            # Debug: print what we got back
            print(f"\nDebug - security_results keys: {security_results.keys()}")
            
            # Try different keys and structures
            if 'output_files' in security_results:
                result_data = security_results['output_files']
                if isinstance(result_data, dict):
                    output_file = result_data.get('xlsx') or result_data.get('excel') or result_data.get('file')
                elif isinstance(result_data, str):
                    output_file = result_data
            elif 'output_file' in security_results:
                output_file = security_results['output_file']
            
            # If still no file, try to find any xlsx file in temp_dir
            if not output_file:
                print("Debug - Searching temp directory for security report...")
                for file in os.listdir(temp_dir):
                    if file.startswith('Security_Analysis') and file.endswith('.xlsx'):
                        output_file = os.path.join(temp_dir, file)
                        print(f"Debug - Found security report: {output_file}")
                        break
            
            if output_file and isinstance(output_file, str) and os.path.exists(output_file):
                security_dst = os.path.join(output_path, os.path.basename(output_file))
                shutil.copy2(output_file, security_dst)
                reports_generated.append(f"Security Analysis: {os.path.basename(output_file)}")
                print(f"\n✓ Security report saved: {os.path.basename(output_file)}")
            else:
                print(f"⚠️  Security report file not found")
                print(f"   Result structure: {security_results}")
        except Exception as e:
            print(f"⚠️  Security analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Security data not found - skipping security analysis")
        print("   Run discovery with scan_type='deep' to collect security data")

    # =========================================================================
    # 4. SPARK JOB OPTIMIZER ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 4/5: RUNNING SPARK JOB OPTIMIZER ANALYSIS")
    print(f"{'='*80}\n")

    if data_paths.get('spark_optimizer_input') and os.path.exists(data_paths['spark_optimizer_input']):
        try:
            import json as _json
            import pandas as pd
            from datetime import datetime as _dt

            _sjo_file = data_paths['spark_optimizer_input']
            _sjo_ext  = os.path.splitext(_sjo_file)[1].lower()
            print(f"✓ Spark optimizer data: {_sjo_file}")

            def _to_df(records):
                return pd.DataFrame(records) if records else pd.DataFrame()

            if _sjo_ext == '.json':
                with open(_sjo_file, encoding='utf-8') as _fh:
                    _raw = _json.load(_fh)
                # scanner output: {'metadata': ..., 'spark_job_optimizer': {...}}
                _sjo_data = _raw.get('spark_job_optimizer', _raw)
                _summary  = _sjo_data.get('summary', {})

            elif _sjo_ext == '.csv':
                _csv_df   = pd.read_csv(_sjo_file)
                _ws_id    = str(_csv_df['workspace_id'].iloc[0])   if 'workspace_id'   in _csv_df.columns and len(_csv_df) else ''
                _ws_name  = str(_csv_df['workspace_name'].iloc[0]) if 'workspace_name' in _csv_df.columns and len(_csv_df) else ''
                _ts_str   = str(_csv_df['scan_timestamp'].iloc[0]) if 'scan_timestamp' in _csv_df.columns and len(_csv_df) else ''
                _lb       = int(_csv_df['lookback_days'].iloc[0])  if 'lookback_days'  in _csv_df.columns and len(_csv_df) else 30
                _base_cols = {'workspace_id', 'workspace_name', 'scan_timestamp', 'lookback_days', 'category'}
                # flatten_for_csv uses category column to tag each row
                _cat_key_map = {
                    'data_skew':            'skewed_jobs',
                    'shuffle_spill':        'shuffle_spill_jobs',
                    'small_files':          'small_file_jobs',
                    'broadcast_candidates': 'broadcast_candidates',
                    'long_running_jobs':    'long_running_jobs',
                    'failed_tasks':         'failed_tasks',
                    'delta_issues':         'delta_issues',
                }
                _sjo_data = {'summary': {
                    'workspace_id': _ws_id, 'workspace_name': _ws_name,
                    'scan_timestamp': _ts_str, 'lookback_days': _lb,
                }}
                for _cat, _key in _cat_key_map.items():
                    _sub = _csv_df[_csv_df['category'] == _cat] if 'category' in _csv_df.columns else pd.DataFrame()
                    _sjo_data[_key] = _sub.drop(
                        columns=[c for c in _base_cols if c in _sub.columns], errors='ignore'
                    ).to_dict(orient='records')
                _summary = _sjo_data['summary']
            else:
                raise ValueError(f"Unsupported spark optimizer file format: {_sjo_ext}")

            # Reconstruct ScanResult from saved dict
            try:
                _scan_ts = _dt.fromisoformat(str(_summary.get('scan_timestamp', '')))
            except Exception:
                _scan_ts = _dt.now()

            sjo_scan_result = SparkScanResult(
                workspace_id         = _summary.get('workspace_id',   ''),
                workspace_name       = _summary.get('workspace_name', ''),
                scan_timestamp       = _scan_ts,
                scan_mode            = _summary.get('scan_mode',      'deep'),
                lookback_days        = int(_summary.get('lookback_days', 30)),
                skewed_jobs          = _to_df(_sjo_data.get('skewed_jobs',          [])),
                shuffle_spill_jobs   = _to_df(_sjo_data.get('shuffle_spill_jobs',   [])),
                small_file_jobs      = _to_df(_sjo_data.get('small_file_jobs',      [])),
                broadcast_candidates = _to_df(_sjo_data.get('broadcast_candidates', [])),
                long_running_jobs    = _to_df(_sjo_data.get('long_running_jobs',    [])),
                failed_tasks         = _to_df(_sjo_data.get('failed_tasks',         [])),
                delta_issues         = _to_df(_sjo_data.get('delta_issues',         [])),
            )
            print(f"  Total findings loaded: {sjo_scan_result.total_findings}")

            # Generate Excel report
            _ws_slug      = (sjo_scan_result.workspace_id or 'workspace').replace('/', '_')
            _sjo_rpt_name = f"Spark_Job_Optimizer_{_ws_slug}.xlsx"
            _sjo_rpt_tmp  = os.path.join(temp_dir, _sjo_rpt_name)

            sjo_analyzer.generate_report(sjo_scan_result, _sjo_rpt_tmp)

            if os.path.exists(_sjo_rpt_tmp):
                shutil.copy2(_sjo_rpt_tmp, os.path.join(output_path, _sjo_rpt_name))
                reports_generated.append(f"Spark Job Optimizer: {_sjo_rpt_name}")
                print(f"✓ Spark Job Optimizer report saved: {_sjo_rpt_name}")

        except Exception as e:
            print(f"⚠️  Spark Job Optimizer analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Spark optimizer data not found — skipping")
        print("   Enable spark_job_optimizer in config.json and re-run discovery")

    # =========================================================================
    # SUMMARY
    # =========================================================================
    print(f"\n{'='*80}")
    print("✓ COMPREHENSIVE ANALYSIS COMPLETE")
    print(f"{'='*80}\n")
    
    print(f"Generated {len(reports_generated)} report(s):\n")
    for report in reports_generated:
        print(f"  📊 {report}")
    
    print(f"\nAll reports saved to: {ANALYSIS_OUTPUT}")
    print(f"\n{'='*80}")
    
except Exception as e:
    print(f"\n❌ Error during comprehensive analysis: {str(e)}")
    import traceback
    traceback.print_exc()
    
finally:
    # Clean up temporary files
    try:
        if os.path.exists(ANALYSIS_TEMP_DIR):
            shutil.rmtree(ANALYSIS_TEMP_DIR)
            print(f"\n✓ Cleaned up temporary files")
        elif os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            print(f"\n✓ Cleaned up temporary files")
    except Exception as e:
        print(f"⚠️  Warning: Could not clean up temp files: {e}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## View Generated Reports
# MAGIC
# MAGIC List all Excel reports generated by the analysis.

# COMMAND ----------

print("="*80)
print("ANALYSIS REPORTS GENERATED")
print("="*80)
print(f"\nOutput directory: {ANALYSIS_OUTPUT}\n")

try:
    files = dbutils.fs.ls(ANALYSIS_OUTPUT)
    
    excel_files = [f for f in files if f.name.endswith('.xlsx')]
    
    if excel_files:
        print(f"Found {len(excel_files)} Excel report(s):\n")
        for file_info in sorted(excel_files, key=lambda x: x.name):
            size_mb = file_info.size / (1024*1024)
            print(f"  📊 {file_info.name}")
            print(f"     Size: {size_mb:.2f} MB")
            print(f"     Path: {file_info.path}\n")
    else:
        print("⚠️  No Excel reports found")
        
except Exception as e:
    print(f"Error listing reports: {e}")

print("="*80)
print("✓ ANALYSIS COMPLETE")
print("="*80)
print("\n📥 Download the Excel reports to view detailed analysis and recommendations.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preview Analysis Results Before Saving to Delta Tables
# MAGIC
# MAGIC Review the summaries below. Once satisfied, run the **Confirm Insert** cell and set the widget to **Yes**, then run the **Insert into Delta Tables** cell to persist the data to Unity Catalog.

# COMMAND ----------

import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# Helper: safe display for DataFrames in Databricks
# Coerces all object-dtype columns to str to prevent Arrow serialisation
# failures caused by mixed-type columns (int / str / None in the same column).
# ─────────────────────────────────────────────────────────────────────────────
def _safe_df(df):
    """Return a copy of df with every object-dtype column cast to str."""
    df = df.copy()
    for col in df.select_dtypes(include='object').columns:
        df[col] = df[col].astype(str)
    return df


def _show(df, title, max_rows=50):
    print(f"\n{'='*80}")
    print(f"  {title}")
    print(f"{'='*80}")
    if df is None or (hasattr(df, '__len__') and len(df) == 0):
        print("  (no data)")
        return
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 200)
    pd.set_option('display.max_colwidth', 60)
    _df = _safe_df(df.head(max_rows))
    try:
        display(_df)          # Databricks rich display
    except NameError:
        print(_df.to_string(index=False))


# ─────────────────────────────────────────────────────────────────────────────
# 1. CLUSTER ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    cluster_df_raw = cluster_results.get('analysis_results', {}).get('utilization', {}).get('cluster_data')
    if cluster_df_raw is not None and not cluster_df_raw.empty:
        preview_cols = [c for c in [
            'cluster_name', 'driver_node_type', 'worker_node_type',
            'Avg CPU Utilization', 'Peak CPU Utilization',
            'Avg Memory Utilization', 'Avg CPU Wait',
            'Avg Network MB Received', 'Avg Network MB Sent',
            'Category', 'Recommendation'
        ] if c in cluster_df_raw.columns]

        cluster_preview = cluster_df_raw[preview_cols].copy()
        cluster_preview.index.name = 'cluster_id'

        # Category breakdown
        print("\n" + "="*80)
        print("  CLUSTER ANALYSIS — Category Breakdown")
        print("="*80)
        cat_summary = cluster_df_raw['Category'].value_counts().reset_index()
        cat_summary.columns = ['Category', 'Count']
        try:
            display(_safe_df(cat_summary))
        except NameError:
            print(cat_summary.to_string(index=False))

        _show(cluster_preview.reset_index(), "CLUSTER ANALYSIS — Per-Cluster Metrics (first 50 rows)")
    else:
        print("⚠️  Cluster analysis data not available in this session")
except Exception as e:
    print(f"⚠️  Could not display cluster data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. JOB ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    job_stats = cluster_results.get('job_stats') or {}
    print("\n" + "="*80)
    print("  JOB ANALYSIS — Summary Statistics")
    print("="*80)
    job_summary_rows = [
        {'Metric': 'Total Jobs',   'Value': str(job_stats.get('total_jobs', 'N/A'))},
        {'Metric': 'Workspace ID', 'Value': str(job_stats.get('workspace_id', 'N/A'))},
        {'Metric': 'Scan Time',    'Value': str(job_stats.get('scan_time', 'N/A'))},
    ]
    job_summary_df = pd.DataFrame(job_summary_rows)
    try:
        display(job_summary_df)
    except NameError:
        print(job_summary_df.to_string(index=False))

    # Attempt to load detailed per-job data for preview
    if data_paths.get('jobs_input') and os.path.exists(data_paths['jobs_input']):
        try:
            from databricks_toolkit.analysis.job_analyzer import JobAnalyzer
            _preview_job_analyzer = JobAnalyzer(data_paths['jobs_input'], '/tmp')
            _preview_job_analyzer.load_data()
            _job_detail_list = []
            for _j in _preview_job_analyzer.jobs_data[:100]:
                _tasks = _j.get('tasks', [])
                _runs  = _j.get('recent_runs', [])
                _job_detail_list.append({
                    'Job ID':            str(_j.get('job_id', '')),
                    'Job Name':          str(_j.get('job_name', 'Unknown')),
                    'Creator':           str(_j.get('creator_user_name', 'Unknown')),
                    'Format':            str(_j.get('format', 'SINGLE_TASK')),
                    'Task Count':        int(len(_tasks)),
                    'Has Notifications': bool(_j.get('email_notifications', {}).get('on_failure')),
                    'Has Retry':         bool(any(t.get('max_retries', 0) for t in _tasks)),
                    'Recent Runs':       int(len(_runs)),
                    'Has Failed Run':    bool(any(r.get('result_state', '').upper() == 'FAILED' for r in _runs)),
                })
            _show(pd.DataFrame(_job_detail_list), "JOB ANALYSIS — Per-Job Preview (first 100 jobs)")
        except Exception as je:
            print(f"  (Detailed per-job preview skipped: {je})")
except Exception as e:
    print(f"⚠️  Could not display job data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 3. SECURITY ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if 'security_results' in dir() or 'security_results' in globals():
        sec_score  = security_results.get('security_score', 'N/A')
        sec_grade  = security_results.get('grade', 'N/A')
        sec_total  = security_results.get('total_findings', 0)
        sec_high   = security_results.get('high_severity_count', 0)
        sec_medium = security_results.get('medium_severity_count', 0)
        sec_low    = security_results.get('low_severity_count', 0)

        print("\n" + "="*80)
        print("  SECURITY ANALYSIS — Score Card")
        print("="*80)
        sec_card = pd.DataFrame([
            {'Metric': 'Security Score',  'Value': f"{sec_score}/100"},
            {'Metric': 'Grade',           'Value': str(sec_grade)},
            {'Metric': 'Total Findings',  'Value': str(sec_total)},
            {'Metric': 'High Severity',   'Value': str(sec_high)},
            {'Metric': 'Medium Severity', 'Value': str(sec_medium)},
            {'Metric': 'Low Severity',    'Value': str(sec_low)},
        ])
        try:
            display(sec_card)
        except NameError:
            print(sec_card.to_string(index=False))

        findings_list = security_results.get('findings', [])
        if findings_list:
            findings_cols = ['check_id', 'check_name', 'category_name', 'severity', 'status',
                             'current_value', 'recommendation']
            findings_df = pd.DataFrame(findings_list)
            findings_df = findings_df[[c for c in findings_cols if c in findings_df.columns]]
            _show(findings_df, "SECURITY ANALYSIS — All Findings")
    else:
        print("⚠️  Security analysis data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display security data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 4. QUERY ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if 'query_results' in dir() or 'query_results' in globals():
        print("\n" + "="*80)
        print("  QUERY ANALYSIS — Summary Statistics")
        print("="*80)
        q_summary = pd.DataFrame([
            {'Metric': 'Total Queries',     'Value': str(query_results.get('total_queries', 'N/A'))},
            {'Metric': 'Unique Users',      'Value': str(query_results.get('unique_users', 'N/A'))},
            {'Metric': 'Unique Warehouses', 'Value': str(query_results.get('unique_warehouses', 'N/A'))},
            {'Metric': 'Failed Queries',    'Value': str(query_results.get('failed_queries', 'N/A'))},
            {'Metric': 'Avg Duration (sec)','Value': str(round(query_results.get('avg_duration_seconds', 0), 2))},
        ])
        try:
            display(q_summary)
        except NameError:
            print(q_summary.to_string(index=False))

        user_stats_df = query_results.get('user_stats')
        if user_stats_df is not None and not user_stats_df.empty:
            _show(user_stats_df.head(20), "QUERY ANALYSIS — Top Users by Cost")

        wh_stats_df = query_results.get('warehouse_stats')
        if wh_stats_df is not None and not wh_stats_df.empty:
            _show(wh_stats_df.head(20), "QUERY ANALYSIS — Per-Warehouse Summary")

        if 'query_analyzer' in dir() or 'query_analyzer' in globals():
            raw_q = getattr(query_analyzer, 'query_data', None)
            if raw_q is not None and not raw_q.empty:
                q_cols = [c for c in ['query_id', 'warehouse_id', 'executed_by',
                                       'duration_seconds', 'is_failed', 'estimated_dbu_cost']
                          if c in raw_q.columns]
                _show(raw_q[q_cols].head(50), "QUERY ANALYSIS — Raw Query Data (first 50)")
    else:
        print("⚠️  Query analysis data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display query data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 5. SPARK JOB OPTIMIZER PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if sjo_scan_result is not None and sjo_scan_result.total_findings > 0:
        print("\n" + "="*80)
        print("  SPARK JOB OPTIMIZER — Summary")
        print("="*80)

        _attr_label = [
            ('skewed_jobs',          'Data Skew'),
            ('shuffle_spill_jobs',   'Shuffle Spill'),
            ('small_file_jobs',      'Small Files'),
            ('broadcast_candidates', 'Broadcast Candidates'),
            ('long_running_jobs',    'Long-Running Jobs'),
            ('failed_tasks',         'Failed Tasks'),
            ('delta_issues',         'Delta Issues'),
        ]
        sjo_summary_rows = []
        for _attr, _label in _attr_label:
            _df = getattr(sjo_scan_result, _attr, pd.DataFrame())
            sjo_summary_rows.append({'Category': _label, 'Findings': 0 if _df is None or _df.empty else len(_df)})
        sjo_summary_rows.append({'Category': 'TOTAL', 'Findings': sjo_scan_result.total_findings})

        _sjo_summary_df = pd.DataFrame(sjo_summary_rows)
        try:
            display(_safe_df(_sjo_summary_df))
        except NameError:
            print(_sjo_summary_df.to_string(index=False))

        # Top findings per category
        for _attr, _label in _attr_label:
            _df = getattr(sjo_scan_result, _attr, pd.DataFrame())
            if _df is not None and not _df.empty:
                _show(_df.head(10), f"SPARK JOB OPTIMIZER — {_label} (first 10)")
    else:
        print("⚠️  Spark Job Optimizer data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display Spark Job Optimizer data: {e}")


print("\n" + "="*80)
print("  PREVIEW COMPLETE — proceed to the next cell to configure Delta insertion")
print("="*80)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Confirm Insert into Delta Tables
# MAGIC
# MAGIC Run the cell below. It will create a **widget** at the top of the notebook.
# MAGIC
# MAGIC 1. Review the widget default value (`No`).  
# MAGIC 2. Change it to **`Yes`** when you are ready to persist the analysis results to Unity Catalog.  
# MAGIC 3. Then run the **Insert into Delta Tables** cell immediately after.

# COMMAND ----------

# ─────────────────────────────────────────────────────────────────────────────
# Confirmation Widget
# Change the widget value to "Yes" at the top of the notebook, then run the
# next cell ("Insert into Delta Tables") to persist analysis results.
# ─────────────────────────────────────────────────────────────────────────────

print("="*80)
print("  Widget created above ↑")
print("="*80)
print("""
  Target catalog : dbscannercatalog
  Target schema  : catalog_inventory
  Tables that will be populated:
    • workspace_analysis_cluster_summary
    • workspace_analysis_job_summary
    • workspace_analysis_security_findings
    • workspace_analysis_query_summary        (only if query data was collected)
    • spark_job_optimizer_findings            (only if spark optimizer data was collected)
    • spark_job_optimizer_recommendations     (only if spark optimizer data was collected)

  ➜  Set widget to "Yes", then run the next cell to insert.
""")


# COMMAND ----------


# ─────────────────────────────────────────────────────────────────────────────
# INSERT ANALYSIS RESULTS INTO UNITY CATALOG DELTA TABLES
# ─────────────────────────────────────────────────────────────────────────────

# ── Guard: only proceed when user explicitly confirms ──────────────────────
_confirm = dbutils.widgets.get("confirm_insert")
if _confirm.strip().lower() != "yes":
    print("⚠️  Insertion skipped.")
    print("   Set the 'Save analysis to Delta Tables?' widget to 'Yes' and re-run this cell.")
    raise SystemExit(0)

# ── Dependencies ───────────────────────────────────────────────────────────
import os
import math
import glob
import json
import uuid as _uuid
import pandas as pd
import numpy as np
from datetime import datetime
from pyspark.sql.types import (
    StructType, StructField,
    StringType, TimestampType, IntegerType,
    LongType, DoubleType, BooleanType
)

# ── Run-level metadata ─────────────────────────────────────────────────────
_analysis_run_id = f"AR_{timestamp}"   # timestamp defined in configuration cell
_analysis_ts     = datetime.now()
_CATALOG         = dbutils.widgets.get("_CATALOG")
_SCHEMA          = dbutils.widgets.get("_SCHEMA")

print("="*80)
print("INSERTING ANALYSIS RESULTS INTO UNITY CATALOG DELTA TABLES")
print("="*80)
print(f"  Run ID          : {_analysis_run_id}")
print(f"  Analysis time   : {_analysis_ts.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"  Target catalog  : {_CATALOG}.{_SCHEMA}")
print("  Mode            : APPEND  (filter by analysis_run_id for latest run)")
print("="*80 + "\n")

# ── Ensure catalog and schema exist ───────────────────────────────────────
try:
    spark.sql(f"CREATE CATALOG IF NOT EXISTS `{_CATALOG}`")
    print(f"  ✓ Catalog '{_CATALOG}' ready")
except Exception as _ce:
    print(f"  ⚠️  Could not create catalog (may already exist or lack permissions): {_ce}")
try:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{_CATALOG}`.`{_SCHEMA}`")
    print(f"  ✓ Schema '{_CATALOG}.{_SCHEMA}' ready\n")
except Exception as _se:
    print(f"  ⚠️  Could not create schema (may already exist or lack permissions): {_se}\n")

_tables_written = []
_tables_skipped = []


# ─────────────────────────────────────────────────────────────────────────────
# Helper: cast pandas DataFrame columns to exact Spark types declared in schema.
# ─────────────────────────────────────────────────────────────────────────────
def _to_spark(pd_df, schema: StructType):
    _PD_MAP = {
        StringType   : lambda s: s.apply(lambda x: str(x) if pd.notna(x) else None),
        IntegerType  : lambda s: pd.to_numeric(s, errors='coerce').astype('Int32'),
        LongType     : lambda s: pd.to_numeric(s, errors='coerce').astype('Int64'),
        DoubleType   : lambda s: pd.to_numeric(s, errors='coerce').astype('float64'),
        BooleanType  : lambda s: s.astype('boolean'),
        TimestampType: lambda s: pd.to_datetime(s, errors='coerce'),
    }
    out = pd_df.copy()
    for field in schema:
        col = field.name
        if col not in out.columns:
            out[col] = None
        caster = _PD_MAP.get(type(field.dataType), lambda s: s)
        try:
            out[col] = caster(out[col])
        except Exception as _ce:
            print(f"    ⚠️  Could not cast column '{col}': {_ce} — leaving as is")
    out = out[[f.name for f in schema]]
    return spark.createDataFrame(out, schema=schema)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: append a Spark DataFrame to a Delta table, self-healing schema
# conflicts by dropping the table and retrying once.
# ─────────────────────────────────────────────────────────────────────────────
def _smart_write(sdf, full_table_name: str):
    _SCHEMA_ERRORS = ("DELTA_MERGE_INCOMPATIBLE_DATATYPE", "DELTA_FAILED_TO_MERGE_FIELDS")
    try:
        (sdf.write
            .format("delta")
            .mode("append")
            .saveAsTable(full_table_name))
    except Exception as _exc:
        _msg = str(_exc)
        if any(e in _msg for e in _SCHEMA_ERRORS):
            print(f"    ⚠️  Schema conflict detected for {full_table_name}.")
            print(f"       Dropping and recreating table with current schema …")
            spark.sql(f"DROP TABLE IF EXISTS {full_table_name}")
            (sdf.write
                .format("delta")
                .mode("append")
                .saveAsTable(full_table_name))
            print(f"    ✓ Table recreated successfully.")
        else:
            raise


# ─────────────────────────────────────────────────────────────────────────────
# Plain-Python coercion helpers — avoid pandas nullable types (Int32/Float64)
# which Spark silently converts to null.
# ─────────────────────────────────────────────────────────────────────────────
def _s(v):
    """Safe string: None for NaN/None, else stripped str."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    return str(v).strip() or None

def _f(v):
    """Safe float: None for NaN/None/non-numeric, else plain Python float."""
    try:
        r = float(v)
        return None if math.isnan(r) else r
    except (TypeError, ValueError):
        return None

def _i(v):
    """Safe int: None for NaN/None/non-numeric, else plain Python int."""
    try:
        r = float(v)
        return None if math.isnan(r) else int(r)
    except (TypeError, ValueError):
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Helper: locate the consolidated cluster Excel file.
#   1. Try cluster_results['cluster_output_file'] (may be deleted by temp cleanup)
#   2. Fall back to newest Cluster_Analysis_Consolidated_*.xlsx in ANALYSIS_OUTPUT
# ─────────────────────────────────────────────────────────────────────────────
def _find_cluster_excel():
    _recorded = cluster_results.get('cluster_output_file', '')
    if _recorded and os.path.exists(_recorded):
        print(f"  ✓ Found Excel at recorded path: {_recorded}")
        return _recorded
    print(f"  ℹ️  Recorded path not found ({_recorded})")
    print(f"      Searching ANALYSIS_OUTPUT: {ANALYSIS_OUTPUT}")
    _candidates = sorted(
        glob.glob(os.path.join(ANALYSIS_OUTPUT, 'Cluster_Analysis_Consolidated_*.xlsx')),
        key=os.path.getmtime, reverse=True
    )
    if _candidates:
        print(f"  ✓ Found Excel in output folder: {_candidates[0]}")
        return _candidates[0]
    print(f"  ❌ No Cluster_Analysis_Consolidated_*.xlsx found in {ANALYSIS_OUTPUT}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
# 1. CLUSTER ANALYSIS  →  workspace_analysis_cluster_summary
# ══════════════════════════════════════════════════════════════════════════════
print("─"*60)
print("STEP 1/5: Inserting cluster analysis …")
print("─"*60)
try:
    _CLUSTER_SHEET = 'utilization_All Clusters'
    _cluster_excel = _find_cluster_excel()

    if _cluster_excel:
        print(f"  Reading sheet '{_CLUSTER_SHEET}' …")
        _cluster_pd = pd.read_excel(_cluster_excel, sheet_name=_CLUSTER_SHEET)
        print(f"  Sheets available : {pd.ExcelFile(_cluster_excel).sheet_names}")
        print(f"  Rows read        : {len(_cluster_pd):,}")
        print(f"  Cols             : {list(_cluster_pd.columns)}")
        if not _cluster_pd.empty:
            print(f"  Row 0            : {_cluster_pd.iloc[0].to_dict()}")
    else:
        _cluster_pd = None

    if _cluster_pd is not None and not _cluster_pd.empty:
        _col_rename = {
            'Avg_CPU_Util'              : 'avg_cpu_utilization',
            'Peak_CPU_Util'             : 'peak_cpu_utilization',
            'Avg_Memory_Util'           : 'avg_memory_utilization',
            'Max_Memory_Util'           : 'max_memory_utilization',
            'Avg_CPU_Wait'              : 'avg_cpu_wait',
            'Max_CPU_Wait'              : 'max_cpu_wait',
            'Avg_Network_MB_Received'   : 'avg_network_mb_received',
            'Avg_Network_MB_Sent'       : 'avg_network_mb_sent',
            'Category'                  : 'category',
            'autoscaling_status'        : 'autoscaling_analysis',
            'Network_Classification'    : 'network_classification',
            'Autoscaling_Recommendation': 'recommendation',
            'Remark'                    : 'recommendation_detail',
        }
        _cluster_pd.rename(columns=_col_rename, inplace=True)

        _cluster_schema = StructType([
            StructField('analysis_run_id',           StringType(),    True),
            StructField('analysis_timestamp',         TimestampType(), True),
            StructField('workspace_id',               StringType(),    True),
            StructField('cluster_id',                 StringType(),    True),
            StructField('cluster_name',               StringType(),    True),
            StructField('job_id',                     StringType(),    True),
            StructField('job_name',                   StringType(),    True),
            StructField('driver_node_type',           StringType(),    True),
            StructField('worker_node_type',           StringType(),    True),
            StructField('min_autoscale_workers',      IntegerType(),   True),
            StructField('max_autoscale_workers',      IntegerType(),   True),
            StructField('avg_cpu_utilization',        DoubleType(),    True),
            StructField('peak_cpu_utilization',       DoubleType(),    True),
            StructField('avg_memory_utilization',     DoubleType(),    True),
            StructField('max_memory_utilization',     DoubleType(),    True),
            StructField('avg_cpu_wait',               DoubleType(),    True),
            StructField('max_cpu_wait',               DoubleType(),    True),
            StructField('avg_network_mb_received',    DoubleType(),    True),
            StructField('avg_network_mb_sent',        DoubleType(),    True),
            StructField('category',                   StringType(),    True),
            StructField('autoscaling_analysis',       StringType(),    True),
            StructField('network_classification',     StringType(),    True),
            StructField('recommendation',             StringType(),    True),
            StructField('recommendation_detail',      StringType(),    True),
        ])

        _cluster_rows = []
        for _, _row in _cluster_pd.iterrows():
            _row = _row.to_dict()
            _cname = _s(_row.get('cluster_name'))
            if not _cname:
                _cname = _s(_row.get('cluster_id'))

            _cluster_rows.append({
                'analysis_run_id'           : _analysis_run_id,
                'analysis_timestamp'        : _analysis_ts,
                'workspace_id'              : '',
                'cluster_id'               : _s(_row.get('cluster_id')),
                'cluster_name'             : _cname,
                'job_id'                   : _s(_row.get('job_id')),
                'job_name'                 : _s(_row.get('job_name')),
                'driver_node_type'         : _s(_row.get('driver_node_type')),
                'worker_node_type'         : _s(_row.get('worker_node_type')),
                'min_autoscale_workers'    : _i(_row.get('min_autoscale_workers')),
                'max_autoscale_workers'    : _i(_row.get('max_autoscale_workers')),
                'avg_cpu_utilization'      : _f(_row.get('avg_cpu_utilization')),
                'peak_cpu_utilization'     : _f(_row.get('peak_cpu_utilization')),
                'avg_memory_utilization'   : _f(_row.get('avg_memory_utilization')),
                'max_memory_utilization'   : _f(_row.get('max_memory_utilization')),
                'avg_cpu_wait'             : _f(_row.get('avg_cpu_wait')),
                'max_cpu_wait'             : _f(_row.get('max_cpu_wait')),
                'avg_network_mb_received'  : _f(_row.get('avg_network_mb_received')),
                'avg_network_mb_sent'      : _f(_row.get('avg_network_mb_sent')),
                'category'                 : _s(_row.get('category')),
                'autoscaling_analysis'     : _s(_row.get('autoscaling_analysis')),
                'network_classification'   : _s(_row.get('network_classification')),
                'recommendation'           : _s(_row.get('recommendation')),
                'recommendation_detail'    : _s(_row.get('recommendation_detail')),
            })

        _cluster_sdf = spark.createDataFrame(_cluster_rows, schema=_cluster_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_cluster_summary"
        _smart_write(_cluster_sdf, _tbl)
        print(f"  ✓ Wrote {_cluster_sdf.count():,} cluster rows  (run_id: {_analysis_run_id})")
        _tables_written.append("workspace_analysis_cluster_summary")
    else:
        print("  ⚠️  Cluster analysis data not found – skipping")
        _tables_skipped.append("workspace_analysis_cluster_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Cluster insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_cluster_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 2. JOB ANALYSIS  →  workspace_analysis_job_summary
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 2/5: Inserting job analysis …")
print("─"*60)
try:
    if data_paths.get('jobs_input') and os.path.exists(data_paths['jobs_input']):
        from databricks_toolkit.analysis.job_analyzer import JobAnalyzer

        _job_analyzer_ins = JobAnalyzer(data_paths['jobs_input'], '/tmp')
        _job_analyzer_ins.load_data()
        _ws_id_job = str(_job_analyzer_ins.metadata.get('workspace_id', ''))

        _job_rows = []
        for _j in _job_analyzer_ins.jobs_data:
            _tasks       = _j.get('tasks', [])
            _runs        = _j.get('recent_runs', [])
            _email_notif = _j.get('email_notifications', {})

            _durations = []
            for _r in _runs:
                _st, _et = _r.get('start_time'), _r.get('end_time')
                if _st and _et:
                    try:
                        _durations.append((int(_et) - int(_st)) / 60000.0)
                    except (ValueError, TypeError):
                        pass

            _has_notif = bool(
                _email_notif.get('on_failure') or
                _email_notif.get('on_success') or
                _email_notif.get('on_start')
            )
            _has_retry = any((t.get('max_retries') or 0) > 0 for t in _tasks)
            _tasks_no_retry = sum(1 for t in _tasks if not (t.get('max_retries') or 0))
            _cluster_types = ','.join({t.get('cluster_type', 'unknown') for t in _tasks})

            _job_rows.append({
                'analysis_run_id'      : _analysis_run_id,
                'analysis_timestamp'   : _analysis_ts,
                'workspace_id'         : _ws_id_job,
                'job_id'               : str(_j.get('job_id', '')),
                'job_name'             : str(_j.get('job_name', 'Unknown')),
                'creator'              : str(_j.get('creator_user_name', 'Unknown')),
                'job_format'           : str(_j.get('format', 'SINGLE_TASK')),
                'task_count'           : len(_tasks),
                'tasks_without_retry'  : _tasks_no_retry,
                'has_retry_policy'     : _has_retry,
                'has_notifications'    : _has_notif,
                'has_recent_failure'   : any(r.get('result_state','').upper() == 'FAILED' for r in _runs),
                'avg_run_duration_mins': sum(_durations)/len(_durations) if _durations else None,
                'p95_run_duration_mins': sorted(_durations)[int(len(_durations)*0.95)] if len(_durations) >= 2 else (_durations[0] if _durations else None),
                'total_runs_analyzed'  : len(_runs),
                'cluster_types'        : _cluster_types,
            })

        _job_schema = StructType([
            StructField('analysis_run_id',       StringType(),    True),
            StructField('analysis_timestamp',     TimestampType(), True),
            StructField('workspace_id',           StringType(),    True),
            StructField('job_id',                 StringType(),    True),
            StructField('job_name',               StringType(),    True),
            StructField('creator',                StringType(),    True),
            StructField('job_format',             StringType(),    True),
            StructField('task_count',             IntegerType(),   True),
            StructField('tasks_without_retry',    IntegerType(),   True),
            StructField('has_retry_policy',       BooleanType(),   True),
            StructField('has_notifications',      BooleanType(),   True),
            StructField('has_recent_failure',     BooleanType(),   True),
            StructField('avg_run_duration_mins',  DoubleType(),    True),
            StructField('p95_run_duration_mins',  DoubleType(),    True),
            StructField('total_runs_analyzed',    IntegerType(),   True),
            StructField('cluster_types',          StringType(),    True),
        ])

        _job_sdf = _to_spark(pd.DataFrame(_job_rows), _job_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_job_summary"
        _smart_write(_job_sdf, _tbl)
        print(f"  ✓ Wrote {_job_sdf.count():,} job rows")
        _tables_written.append("workspace_analysis_job_summary")
    else:
        print("  ⚠️  Job data path not found – skipping")
        _tables_skipped.append("workspace_analysis_job_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Job insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_job_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 3. SECURITY ANALYSIS  →  workspace_analysis_security_findings
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 3/5: Inserting security findings …")
print("─"*60)
try:
    _sec_available = 'security_results' in vars() or 'security_results' in globals()
    if _sec_available and security_results:
        _findings_list = security_results.get('findings', [])
        _overall_score = int(security_results.get('security_score', 0))
        _ws_id_sec     = str(security_results.get('workspace_id', ''))

        if _findings_list:
            _sec_rows = [{
                'analysis_run_id'       : _analysis_run_id,
                'analysis_timestamp'    : _analysis_ts,
                'workspace_id'          : _ws_id_sec,
                'check_id'              : str(_f.get('check_id', '')),
                'check_name'            : str(_f.get('check_name', '')),
                'category'              : str(_f.get('category_name', _f.get('category', ''))),
                'severity'              : str(_f.get('severity', '')),
                'status'                : str(_f.get('status', '')),
                'score'                 : int(_f.get('severity_score', 0)),
                'finding'               : str(_f.get('current_value', '')),
                'recommendation'        : str(_f.get('recommendation', '')),
                'detail'                : str(_f.get('expected_value', '')),
                'overall_security_score': _overall_score,
            } for _f in _findings_list]

            _sec_schema = StructType([
                StructField('analysis_run_id',        StringType(),    True),
                StructField('analysis_timestamp',      TimestampType(), True),
                StructField('workspace_id',            StringType(),    True),
                StructField('check_id',                StringType(),    True),
                StructField('check_name',              StringType(),    True),
                StructField('category',                StringType(),    True),
                StructField('severity',                StringType(),    True),
                StructField('status',                  StringType(),    True),
                StructField('score',                   IntegerType(),   True),
                StructField('finding',                 StringType(),    True),
                StructField('recommendation',          StringType(),    True),
                StructField('detail',                  StringType(),    True),
                StructField('overall_security_score',  IntegerType(),   True),
            ])

            _sec_sdf = _to_spark(pd.DataFrame(_sec_rows), _sec_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_security_findings"
            _smart_write(_sec_sdf, _tbl)
            print(f"  ✓ Wrote {_sec_sdf.count():,} security finding rows  (score: {_overall_score}/100)")
            _tables_written.append("workspace_analysis_security_findings")
        else:
            print("  ⚠️  No security findings in results – skipping")
            _tables_skipped.append("workspace_analysis_security_findings")
    else:
        print("  ⚠️  Security analysis was not run or failed – skipping")
        _tables_skipped.append("workspace_analysis_security_findings")
except Exception as _e:
    import traceback
    print(f"  ❌ Security insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_security_findings")


# ══════════════════════════════════════════════════════════════════════════════
# 4. QUERY ANALYSIS  →  workspace_analysis_query_summary
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 4/5: Inserting query analysis …")
print("─"*60)
try:
    _query_available = (
        ('query_analyzer' in vars() or 'query_analyzer' in globals()) and
        getattr(query_analyzer, 'query_data', None) is not None and
        not query_analyzer.query_data.empty
    )
    if _query_available:
        _q_pd = query_analyzer.query_data.copy()

        _q_rename = {
            'query_id'          : 'query_id',
            'warehouse_id'      : 'warehouse_id',
            'executed_by'       : 'user_name',
            'statement_text'    : 'query_text_preview',
            'total_duration_ms' : 'duration_ms',
            'rows_produced'     : 'rows_produced',
            'estimated_dbu_cost': 'bytes_scanned',
            'error_message'     : 'recommendation',
        }
        _q_pd.rename(columns={k: v for k, v in _q_rename.items() if k in _q_pd.columns}, inplace=True)

        if 'duration_ms' in _q_pd.columns:
            _q_pd['duration_mins']   = pd.to_numeric(_q_pd['duration_ms'], errors='coerce') / 60000.0
            _q_pd['is_long_running'] = pd.to_numeric(_q_pd['duration_ms'], errors='coerce') > 300_000
        else:
            _q_pd['duration_mins']   = None
            _q_pd['is_long_running'] = None

        if 'query_text_preview' in _q_pd.columns:
            _q_pd['query_text_preview'] = _q_pd['query_text_preview'].astype(str).str[:500]

        def _perf_cat(ms):
            try:
                ms = float(ms)
            except (TypeError, ValueError):
                return 'Unknown'
            if ms < 5_000:   return 'Fast'
            if ms < 60_000:  return 'Normal'
            if ms < 300_000: return 'Slow'
            return 'Very Slow'
        _q_pd['performance_category'] = _q_pd.get('duration_ms', pd.Series(dtype=float)).apply(_perf_cat)

        _q_pd['analysis_run_id']    = _analysis_run_id
        _q_pd['analysis_timestamp'] = _analysis_ts
        _q_pd['workspace_id']       = ''

        _q_schema = StructType([
            StructField('analysis_run_id',      StringType(),    True),
            StructField('analysis_timestamp',    TimestampType(), True),
            StructField('workspace_id',          StringType(),    True),
            StructField('query_id',              StringType(),    True),
            StructField('warehouse_id',          StringType(),    True),
            StructField('user_name',             StringType(),    True),
            StructField('query_text_preview',    StringType(),    True),
            StructField('duration_ms',           DoubleType(),    True),
            StructField('duration_mins',         DoubleType(),    True),
            StructField('rows_produced',         DoubleType(),    True),
            StructField('bytes_scanned',         DoubleType(),    True),
            StructField('is_long_running',       BooleanType(),   True),
            StructField('performance_category',  StringType(),    True),
            StructField('recommendation',        StringType(),    True),
        ])

        _q_sdf = _to_spark(_q_pd, _q_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_query_summary"
        _smart_write(_q_sdf, _tbl)
        print(f"  ✓ Wrote {_q_sdf.count():,} query rows")
        _tables_written.append("workspace_analysis_query_summary")
    else:
        print("  ⚠️  Query analysis was not run or has no data – skipping")
        _tables_skipped.append("workspace_analysis_query_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Query insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_query_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 5. SPARK JOB OPTIMIZER  →  spark_job_optimizer_findings
#                           →  spark_job_optimizer_recommendations
#
#    Iterates over all 7 ScanResult finding DataFrames and inserts them.
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 5/5: Inserting Spark Job Optimizer findings & recommendations …")
print("─"*60)
try:
    _sjo_ok = (sjo_scan_result is not None and sjo_scan_result.total_findings > 0)
    if _sjo_ok:
        _sjo_ts    = sjo_scan_result.scan_timestamp
        _sjo_ws_id = sjo_scan_result.workspace_id

        # Generate recommendations (same engine used inside generate_report())
        _sjo_recs = SparkRecommendationEngine({}).generate_recommendations(sjo_scan_result)

        # ── Build findings rows ───────────────────────────────────────────────────
        _CAT_MAP = [
            ('skewed_jobs',          'data_skew'),
            ('shuffle_spill_jobs',   'shuffle_spill'),
            ('small_file_jobs',      'small_files'),
            ('broadcast_candidates', 'broadcast_candidates'),
            ('long_running_jobs',    'long_running_jobs'),
            ('failed_tasks',         'failed_tasks'),
            ('delta_issues',         'delta_issues'),
        ]
        def _sev_for(cat, rd):
            if cat == 'delta_issues':
                d = str(rd.get('issue_description', ''))
                return 'HIGH' if 'CRITICAL' in d else ('MEDIUM' if 'WARNING' in d else 'LOW')
            if cat == 'failed_tasks':
                return 'HIGH' if float(rd.get('failure_pct', 0) or 0) >= 50 else 'MEDIUM'
            if cat == 'data_skew':
                return 'HIGH' if float(rd.get('skew_ratio', 0) or 0) >= 20 else 'MEDIUM'
            return 'MEDIUM'

        _finding_rows = []
        for _attr, _category in _CAT_MAP:
            _raw_df = getattr(sjo_scan_result, _attr, None)
            if _raw_df is None or (hasattr(_raw_df, 'empty') and _raw_df.empty):
                continue
            for _, _row in _raw_df.iterrows():
                _rd = _row.to_dict()
                _finding_rows.append({
                    'finding_id'      : str(_uuid.uuid4()),
                    'scan_id'         : _analysis_run_id,
                    'workspace_id'    : _sjo_ws_id,
                    'workspace_name'  : sjo_scan_result.workspace_name,
                    'scan_timestamp'  : _sjo_ts,
                    'lookback_days'   : sjo_scan_result.lookback_days,
                    'category'        : _category,
                    'severity'        : _sev_for(_category, _rd),
                    'job_id'          : _s(_rd.get('job_id',        '')),
                    'run_id'          : _s(_rd.get('run_id',        '')),
                    'query_id'        : _s(_rd.get('query_id',      '')),
                    'table_catalog'   : _s(_rd.get('table_catalog', '')),
                    'table_schema'    : _s(_rd.get('table_schema',  '')),
                    'table_name'      : _s(_rd.get('table_name',    '')),
                    'skew_ratio'      : _f(_rd.get('skew_ratio')),
                    'spill_mb'        : _f(_rd.get('spill_mb')),
                    'read_mb'         : _f(_rd.get('read_mb')),
                    'num_files'       : _f(_rd.get('num_files')),
                    'duration_mins'   : _f(_rd.get('duration_mins')),
                    'failure_pct'     : _f(_rd.get('failure_pct')),
                    'days_since_alter': _i(_rd.get('days_since_last_alter')),
                    'details_json'    : json.dumps(
                        {k: str(v) for k, v in _rd.items()}, default=str
                    ),
                })

        if _finding_rows:
            _findings_schema = StructType([
                StructField('finding_id',       StringType(),    True),
                StructField('scan_id',          StringType(),    True),
                StructField('workspace_id',     StringType(),    True),
                StructField('workspace_name',   StringType(),    True),
                StructField('scan_timestamp',   TimestampType(), True),
                StructField('lookback_days',    IntegerType(),   True),
                StructField('category',         StringType(),    True),
                StructField('severity',         StringType(),    True),
                StructField('job_id',           StringType(),    True),
                StructField('run_id',           StringType(),    True),
                StructField('query_id',         StringType(),    True),
                StructField('table_catalog',    StringType(),    True),
                StructField('table_schema',     StringType(),    True),
                StructField('table_name',       StringType(),    True),
                StructField('skew_ratio',       DoubleType(),    True),
                StructField('spill_mb',         DoubleType(),    True),
                StructField('read_mb',          DoubleType(),    True),
                StructField('num_files',        DoubleType(),    True),
                StructField('duration_mins',    DoubleType(),    True),
                StructField('failure_pct',      DoubleType(),    True),
                StructField('days_since_alter', IntegerType(),   True),
                StructField('details_json',     StringType(),    True),
            ])
            _findings_sdf = spark.createDataFrame(_finding_rows, schema=_findings_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.spark_job_optimizer_findings"
            _smart_write(_findings_sdf, _tbl)
            print(f"  ✓ Wrote {_findings_sdf.count():,} finding rows  → spark_job_optimizer_findings")
            _tables_written.append("spark_job_optimizer_findings")
        else:
            print("  ⚠️  No findings to write")
            _tables_skipped.append("spark_job_optimizer_findings")

        # ── Build recommendations rows ───────────────────────────────────────
        if _sjo_recs:
            _rec_rows = [{
                'recommendation_id': r.recommendation_id,
                'scan_id'          : _analysis_run_id,
                'workspace_id'     : _sjo_ws_id,
                'scan_timestamp'   : _sjo_ts,
                'finding_id'       : r.finding_id,
                'category'         : r.category,
                'priority'         : r.priority,
                'issue_summary'    : r.issue_summary,
                'actions'          : '\n'.join(r.actions),
                'sql_scripts'      : '\n\n'.join(r.sql_scripts),
                'estimated_savings': r.estimated_savings,
                'reference_docs'   : '\n'.join(r.reference_docs),
            } for r in _sjo_recs]

            _rec_schema = StructType([
                StructField('recommendation_id', StringType(),    True),
                StructField('scan_id',           StringType(),    True),
                StructField('workspace_id',      StringType(),    True),
                StructField('scan_timestamp',    TimestampType(), True),
                StructField('finding_id',        StringType(),    True),
                StructField('category',          StringType(),    True),
                StructField('priority',          StringType(),    True),
                StructField('issue_summary',     StringType(),    True),
                StructField('actions',           StringType(),    True),
                StructField('sql_scripts',       StringType(),    True),
                StructField('estimated_savings', StringType(),    True),
                StructField('reference_docs',    StringType(),    True),
            ])
            _rec_sdf = _to_spark(pd.DataFrame(_rec_rows), _rec_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.spark_job_optimizer_recommendations"
            _smart_write(_rec_sdf, _tbl)
            print(f"  ✓ Wrote {_rec_sdf.count():,} recommendation rows  → spark_job_optimizer_recommendations")
            _tables_written.append("spark_job_optimizer_recommendations")
        else:
            print("  ⚠️  No recommendations generated")
            _tables_skipped.append("spark_job_optimizer_recommendations")
    else:
        print("  ⚠️  Spark optimizer scan result not available — skipping")
        _tables_skipped.append("spark_job_optimizer_findings")
        _tables_skipped.append("spark_job_optimizer_recommendations")
except Exception as _e:
    import traceback
    print(f"  ❌ Spark Job Optimizer insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("spark_job_optimizer_findings")
    _tables_skipped.append("spark_job_optimizer_recommendations")


# ══════════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*80)
print("  DELTA INSERT COMPLETE")
print("="*80)
print(f"\n  Run ID : {_analysis_run_id}")
print(f"\n  ✅ Tables written ({len(_tables_written)}):")
for _t in _tables_written:
    print(f"       {_CATALOG}.{_SCHEMA}.{_t}")
if _tables_skipped:
    print(f"\n  ⚠️  Tables skipped ({len(_tables_skipped)}):")
    for _t in _tables_skipped:
        print(f"       {_t}")

print(f"\n  To query only the latest run's cluster results:")
print(f"    SELECT * FROM `{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_cluster_summary")
print(f"    WHERE analysis_run_id = '{_analysis_run_id}';")
print("\n" + "="*80)


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `ext_nyc_cat_ci`.`catalog_inventory`.workspace_analysis_cluster_summary WHERE analysis_run_id = 'AR_1774789602';