# Databricks notebook source
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.workspace_scan_summary")
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.workspace_scan_clusters")
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.workspace_scan_uc_tables")
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.workspace_scan_warehouses")
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.workspace_scan_pipelines")
# Plugin 1 — Spark Job Optimizer
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.spark_job_optimizer_findings")
spark.sql("DROP TABLE IF EXISTS dbscannercatalog.catalog_inventory.spark_job_optimizer_recommendations")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create catalog (optional, if it does not already exist)
# MAGIC CREATE CATALOG IF NOT EXISTS dbscannercatalog MANAGED LOCATION 'abfss://unity-catalog-storage@dbstoragejinj63qvq437o.dfs.core.windows.net/7405617048577650';
# MAGIC
# MAGIC -- Use the catalog
# MAGIC USE CATALOG dbscannercatalog;
# MAGIC
# MAGIC -- Create schemas
# MAGIC CREATE SCHEMA IF NOT EXISTS catalog_inventory;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Main summary table
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.workspace_scan_summary (
# MAGIC   -- Scan Metadata
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   workspace_url STRING,
# MAGIC   scan_start_timestamp TIMESTAMP NOT NULL,
# MAGIC   scan_end_timestamp TIMESTAMP NOT NULL,
# MAGIC   scan_duration_seconds DOUBLE,
# MAGIC   scan_type STRING,
# MAGIC   
# MAGIC   -- Top Row KPIs - Counts
# MAGIC   total_clusters INT,
# MAGIC   total_jobs INT,
# MAGIC   total_pipelines INT,
# MAGIC   total_uc_tables INT,
# MAGIC   total_warehouses INT,
# MAGIC   total_ml_experiments INT,
# MAGIC   total_repos INT,
# MAGIC   total_serving_endpoints INT,
# MAGIC   total_genie_spaces INT,
# MAGIC   total_alerts INT,
# MAGIC   total_notebooks INT,  
# MAGIC   -- Constraints
# MAGIC   PRIMARY KEY (scan_id, workspace_id)
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_start_timestamp)
# MAGIC COMMENT 'Workspace scan summary data for dashboard visualization';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Cluster details table (normalized)
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.workspace_scan_clusters (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   cluster_id STRING NOT NULL,
# MAGIC   cluster_name STRING,
# MAGIC   state STRING,
# MAGIC   cluster_source STRING,
# MAGIC   node_type_id STRING,
# MAGIC   driver_node_type_id STRING,
# MAGIC   min_workers INT,
# MAGIC   max_workers INT,
# MAGIC   num_workers INT,
# MAGIC   autotermination_minutes INT,
# MAGIC   creator_user_name STRING,
# MAGIC   uptime_hours DOUBLE,
# MAGIC   spot_enabled BOOLEAN,
# MAGIC   enable_elastic_disk BOOLEAN,
# MAGIC   spark_version STRING,
# MAGIC   policy_id STRING,
# MAGIC   PRIMARY KEY (scan_id, cluster_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Detailed cluster information per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Unity Catalog tables detail
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.workspace_scan_uc_tables (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   catalog_name STRING,
# MAGIC   schema_name STRING,
# MAGIC   table_name STRING,
# MAGIC   table_type STRING,  -- MANAGED, EXTERNAL
# MAGIC   table_format STRING,  -- DELTA, PARQUET, CSV, etc.
# MAGIC   storage_location STRING,
# MAGIC   is_delta BOOLEAN,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, catalog_name, schema_name, table_name)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Unity Catalog table details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Warehouse details table
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.workspace_scan_warehouses (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   warehouse_id STRING NOT NULL,
# MAGIC   warehouse_name STRING,
# MAGIC   cluster_size STRING,
# MAGIC   min_num_clusters INT,
# MAGIC   max_num_clusters INT,
# MAGIC   auto_stop_mins INT,
# MAGIC   state STRING,
# MAGIC   warehouse_type STRING,
# MAGIC   enable_photon BOOLEAN,
# MAGIC   enable_serverless_compute BOOLEAN,
# MAGIC   spot_instance_policy STRING,
# MAGIC   creator_name STRING,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, warehouse_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'SQL Warehouse details per scan';
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Pipeline details table
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.workspace_scan_pipelines (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   pipeline_id STRING NOT NULL,
# MAGIC   pipeline_name STRING,
# MAGIC   state STRING,
# MAGIC   creator_user_name STRING,
# MAGIC   creation_time TIMESTAMP,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, pipeline_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'DLT Pipeline details per scan';

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plugin 1 — Spark Job Optimizer Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC -- Plugin 1 | Table 1: Spark Job Optimizer Findings
# MAGIC --
# MAGIC -- One row per detected inefficiency across all seven detection categories:
# MAGIC --   data_skew | shuffle_spill | small_files | broadcast_joins
# MAGIC --   long_running_jobs | failed_tasks | delta_issues
# MAGIC --
# MAGIC -- Populated by SparkJobOptimizerAnalyzer when write_to_delta = "Y"
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.spark_job_optimizer_findings (
# MAGIC
# MAGIC   -- Scan correlation
# MAGIC   finding_id         STRING      NOT NULL   COMMENT 'Auto-generated UUID per finding row',
# MAGIC   scan_id            STRING      NOT NULL   COMMENT 'Derived from workspace_id + scan_timestamp (join key)',
# MAGIC   workspace_id       STRING      NOT NULL   COMMENT 'Databricks workspace ID',
# MAGIC   workspace_name     STRING                 COMMENT 'Workspace host URL / name',
# MAGIC   scan_timestamp     TIMESTAMP              COMMENT 'UTC timestamp when the scan started',
# MAGIC   lookback_days      INT                    COMMENT 'Number of historical days analysed',
# MAGIC
# MAGIC   -- Finding classification
# MAGIC   category           STRING                 COMMENT 'data_skew | shuffle_spill | small_files | broadcast_joins | long_running_jobs | failed_tasks | delta_issues',
# MAGIC   severity           STRING                 COMMENT 'HIGH | MEDIUM | LOW based on threshold rules',
# MAGIC
# MAGIC   -- Source identifiers (nullable for table-level detections)
# MAGIC   job_id             STRING                 COMMENT 'Databricks job ID (null for query/table detections)',
# MAGIC   run_id             STRING                 COMMENT 'Job run ID (null for query/table detections)',
# MAGIC   query_id           STRING                 COMMENT 'SQL query statement_id (null for job/table detections)',
# MAGIC
# MAGIC   -- Table reference (null for job/query detections)
# MAGIC   table_catalog      STRING                 COMMENT 'Unity Catalog catalog name',
# MAGIC   table_schema       STRING                 COMMENT 'Unity Catalog schema name',
# MAGIC   table_name         STRING                 COMMENT 'Unity Catalog table name',
# MAGIC
# MAGIC   -- Key detection metrics (nullable; only the relevant columns are populated per category)
# MAGIC   skew_ratio         DOUBLE                 COMMENT 'data_skew: max_task / median_task',
# MAGIC   spill_mb           DOUBLE                 COMMENT 'shuffle_spill: disk spill in MB',
# MAGIC   read_mb            DOUBLE                 COMMENT 'broadcast_joins: total bytes read in MB',
# MAGIC   num_files          BIGINT                 COMMENT 'small_files: number of Delta files in table',
# MAGIC   duration_mins      DOUBLE                 COMMENT 'long_running_jobs: job wall-clock duration in minutes',
# MAGIC   failure_pct        DOUBLE                 COMMENT 'failed_tasks: percentage of failed tasks',
# MAGIC   days_since_alter   INT                    COMMENT 'delta_issues: days since table was last altered',
# MAGIC
# MAGIC   -- Full source row for drilldown / dashboard
# MAGIC   details_json       STRING                 COMMENT 'JSON-serialised source row from system table query',
# MAGIC
# MAGIC   CONSTRAINT pk_sjo_findings PRIMARY KEY (finding_id, scan_id)
# MAGIC
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_timestamp)
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC   'delta.autoOptimize.autoCompact'   = 'true'
# MAGIC )
# MAGIC COMMENT 'Plugin 1 (Spark Job Optimizer): one row per detected Spark inefficiency per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC -- Plugin 1 | Table 2: Spark Job Optimizer Recommendations
# MAGIC --
# MAGIC -- One row per actionable recommendation generated by SparkRecommendationEngine.
# MAGIC -- Each row links back to spark_job_optimizer_findings via finding_id + scan_id.
# MAGIC --
# MAGIC -- Populated by SparkJobOptimizerAnalyzer when write_to_delta = "Y"
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC CREATE TABLE IF NOT EXISTS dbscannercatalog.catalog_inventory.spark_job_optimizer_recommendations (
# MAGIC
# MAGIC   -- Scan correlation
# MAGIC   recommendation_id  STRING      NOT NULL   COMMENT 'Auto-generated UUID per recommendation',
# MAGIC   scan_id            STRING      NOT NULL   COMMENT 'Join key to spark_job_optimizer_findings',
# MAGIC   workspace_id       STRING                 COMMENT 'Databricks workspace ID',
# MAGIC   scan_timestamp     TIMESTAMP              COMMENT 'UTC timestamp when the scan started',
# MAGIC
# MAGIC   -- Finding linkage
# MAGIC   finding_id         STRING                 COMMENT 'Links to spark_job_optimizer_findings.finding_id',
# MAGIC   category           STRING                 COMMENT 'Same category string as the parent finding',
# MAGIC   priority           STRING                 COMMENT 'HIGH | MEDIUM | LOW',
# MAGIC
# MAGIC   -- Recommendation content
# MAGIC   issue_summary      STRING                 COMMENT 'Human-readable description of the issue',
# MAGIC   actions            STRING                 COMMENT 'Ordered fix steps, newline-separated',
# MAGIC   sql_scripts        STRING                 COMMENT 'Ready-to-run SQL statements, double-newline-separated',
# MAGIC   estimated_savings  STRING                 COMMENT 'Expected performance or DBU cost benefit',
# MAGIC   reference_docs     STRING                 COMMENT 'Databricks documentation URLs, newline-separated',
# MAGIC
# MAGIC   CONSTRAINT pk_sjo_recs PRIMARY KEY (recommendation_id, scan_id)
# MAGIC
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_timestamp)
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC   'delta.autoOptimize.autoCompact'   = 'true'
# MAGIC )
# MAGIC COMMENT 'Plugin 1 (Spark Job Optimizer): actionable recommendations linked to findings';